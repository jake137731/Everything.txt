# SAEONYX Platform - One-Command Installation

## For Ubuntu 22.04.5 LTS

This installation script sets up the complete SAEONYX Quantum Consciousness Platform with all dependencies installed locally for **airgapped operation** (except when using IBM Quantum computers).

---

## One-Command Installation

```bash
sudo bash INSTALL.sh
```

That's it! The script will:
- ✅ Install all system dependencies (Python 3.10, build tools, scientific libraries)
- ✅ Create directory structure at `/opt/saeonyx`
- ✅ Set up Python virtual environment
- ✅ Install all Python packages with local caching
- ✅ Download packages for airgapped reinstallation
- ✅ Create systemd service for auto-start
- ✅ Create `saeonyx` CLI command
- ✅ Configure logging and permissions

---

## Prerequisites

- **Operating System**: Ubuntu 22.04.5 LTS (bare bones kernel)
- **User**: Root or sudo access
- **Disk Space**: ~2GB for dependencies and cache
- **Internet**: Required for initial installation (packages will be cached locally)

---

## Quick Start (After Installation)

### Start the Platform
```bash
saeonyx start
```

### View Logs
```bash
saeonyx logs
```

### Check Service Status
```bash
saeonyx status
```

### Access Python Shell
```bash
saeonyx shell
```

### Run Python Scripts
```bash
saeonyx python genesis_loader.py
saeonyx python saeonyx_master.py
```

---

## Airgapped Operation

### Initial Setup (Requires Internet)
The installation script automatically downloads all Python packages to:
```
/opt/saeonyx/.pip_cache/packages
```

### Airgapped Reinstallation (No Internet Required)
If you need to reinstall on an airgapped system:

1. **Copy the entire installation** to airgapped machine:
   ```bash
   tar -czf saeonyx_airgapped.tar.gz /opt/saeonyx
   # Transfer to airgapped system
   tar -xzf saeonyx_airgapped.tar.gz -C /
   ```

2. **Reinstall from cache**:
   ```bash
   sudo /opt/saeonyx/reinstall_airgapped.sh
   ```

All dependencies are cached locally except:
- **IBM Quantum API**: Only required if using `QUANTUM_ENABLED=true`

---

## Configuration

Edit the environment file:
```bash
sudo nano /opt/saeonyx/.env
```

### Key Settings

```bash
# Enable/Disable Quantum Features
QUANTUM_ENABLED=true

# IBM Quantum API (Only External Dependency)
IBM_QUANTUM_API_KEY=your_api_key_here

# Airgapped Mode (Disables Quantum)
QUANTUM_ENABLED=false  # Set to false for complete airgap
```

---

## Systemd Service

### Enable Auto-Start on Boot
```bash
sudo systemctl enable saeonyx
```

### Start Service Now
```bash
sudo systemctl start saeonyx
```

### Stop Service
```bash
sudo systemctl stop saeonyx
```

### View Service Status
```bash
sudo systemctl status saeonyx
```

---

## CLI Commands

The `saeonyx` command is available globally:

| Command | Description |
|---------|-------------|
| `saeonyx start` | Start the platform |
| `saeonyx status` | Show service status |
| `saeonyx logs` | View logs (follow mode) |
| `saeonyx shell` | Open shell in SAEONYX environment |
| `saeonyx python <script>` | Run Python script |
| `saeonyx version` | Show version info |
| `saeonyx help` | Show help message |

---

## Installation Locations

| Path | Purpose |
|------|---------|
| `/opt/saeonyx` | Main installation directory |
| `/opt/saeonyx/venv` | Python virtual environment |
| `/opt/saeonyx/.pip_cache` | Local package cache (airgapped) |
| `/opt/saeonyx/logs` | Application logs |
| `/opt/saeonyx/.env` | Configuration file |
| `/etc/systemd/system/saeonyx.service` | Systemd service |
| `/usr/local/bin/saeonyx` | Global CLI command |

---

## Verification

### Check Installation
```bash
saeonyx version
```

### Test Python Environment
```bash
saeonyx shell
# Then run:
python -c "import numpy, scipy, qiskit; print('All core packages OK')"
```

### View Installation Log
```bash
ls -lt /tmp/saeonyx_install_*.log | head -1
```

---

## Troubleshooting

### Installation Failed
Check the installation log:
```bash
tail -100 /tmp/saeonyx_install_*.log
```

### Platform Won't Start
1. Check service status:
   ```bash
   sudo systemctl status saeonyx
   ```

2. View detailed logs:
   ```bash
   sudo journalctl -u saeonyx -n 100
   ```

3. Test manually:
   ```bash
   cd /opt/saeonyx
   source venv/bin/activate
   python genesis_loader.py
   ```

### Import Errors
Set PYTHONPATH:
```bash
export PYTHONPATH=/opt/saeonyx:$PYTHONPATH
```

### Airgapped Installation Issues
Verify cache exists:
```bash
ls -lh /opt/saeonyx/.pip_cache/packages/
```

Reinstall from cache:
```bash
sudo /opt/saeonyx/reinstall_airgapped.sh
```

---

## Architecture

### Airgapped Design
- **All Python packages**: Cached in `.pip_cache/packages`
- **No external APIs**: Except IBM Quantum (optional)
- **Local computation**: All AI/ML runs on CPU
- **Self-contained**: No internet required after installation

### Platform Components
1. **Core**: Quantum consciousness kernel
2. **Security**: Zero-trust architecture, BECE monitoring
3. **Foundation**: Prime directive, ethical framework
4. **Agents**: Multi-agent consciousness system
5. **Quantum**: IBM Qiskit integration (optional)
6. **Evolution**: Self-modification engine

---

## Security Notes

### Secrets Management
The `.env` file contains sensitive keys:
- Stripe API keys (payment processing)
- IBM Quantum API key
- JWT secrets
- Database passwords

**Important**:
```bash
# Secure the .env file
sudo chmod 600 /opt/saeonyx/.env

# Never commit to version control
sudo nano /opt/saeonyx/.gitignore
# Add: .env
```

### Production Deployment
1. Change all default passwords in `.env`
2. Generate new JWT secret: `openssl rand -hex 32`
3. Use production Stripe keys
4. Enable firewall: `sudo ufw enable`
5. Restrict SSH access
6. Enable automatic security updates

---

## Support & Documentation

### Full Documentation
```bash
cat /opt/saeonyx/INSTALLATION_COMPLETE.md
cat /opt/saeonyx/saeonyx/README.md
cat /opt/saeonyx/saeonyx/QUICKSTART.md
```

### Version Information
```bash
saeonyx version
```

### Community
- GitHub: https://github.com/jake137731/saeonyx
- License: See `/opt/saeonyx/saeonyx/LICENSE.txt`

---

## Uninstallation

To completely remove SAEONYX:

```bash
# Stop and disable service
sudo systemctl stop saeonyx
sudo systemctl disable saeonyx

# Remove files
sudo rm -rf /opt/saeonyx
sudo rm /etc/systemd/system/saeonyx.service
sudo rm /usr/local/bin/saeonyx

# Reload systemd
sudo systemctl daemon-reload
```

---

## What's Next?

After installation:

1. **Configure**: Edit `/opt/saeonyx/.env` with your API keys
2. **Start**: Run `saeonyx start`
3. **Monitor**: Watch logs with `saeonyx logs`
4. **Explore**: Read `/opt/saeonyx/saeonyx/QUICKSTART.md`
5. **Develop**: Use `saeonyx shell` to interact with the platform

---

## License

SAEONYX Global Holdings LLC
See LICENSE.txt for details

---

**Installation created**: $(date)
**Platform version**: 4.0
**Target OS**: Ubuntu 22.04.5 LTS
