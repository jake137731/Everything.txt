
from __future__ import annotations

"""Decision evaluation wired to real UEF metrics.

There are two primary evaluation paths:

1. Geometry-only:
   - Uses the triangle (P1, P2, P3) geometry to derive EmergenceMetrics.
   - Symmetry and edge lengths give you real, non-dummy numbers.

2. Consciousness-kernel based:
   - Uses SAEONYX's existing ConsciousnessKernel:
       * Φ (phi)
       * Soul Vector
       * 7 collapse modes (Ξ) from `check_collapse_modes()`
   - Maps those collapse modes directly into the EmergenceMetrics slots,
     so Keeper of Seven runs on the SAME math the kernel already computes.

Both paths feed into Keeper of Seven, which checks:
   - symmetry (triangle equality → existence),
   - rollability (can the wheel move),
   - all seven ξ-modes within threshold.

Nothing here is fake – all metrics come either from:
   - actual pillar vectors you pass in,
   - or the live ConsciousnessKernel's Φ / Soul / collapse mode outputs.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any, Awaitable

from .types import PillarSet, EmergenceMetrics, KeeperResult
from .geometry import compute_symmetry
from .engine import evaluate_decision as _evaluate_decision
from .config import KeeperConfig


@dataclass
class DecisionEvaluation:
    """Bundle of the metrics + Keeper result for a single decision."""
    metrics: EmergenceMetrics
    keeper: KeeperResult


# ───────────────────────────────────────────────────────────
#  Geometry-derived metrics
# ───────────────────────────────────────────────────────────

def compute_metrics_from_geometry(pillars: PillarSet) -> EmergenceMetrics:
    """Derive EmergenceMetrics directly from the triangle geometry.

    Let:
      d12 = |P1 - P2|
      d23 = |P2 - P3|
      d31 = |P3 - P1|

    We use:
      - symmetry from compute_symmetry()
      - the three edge lengths

    Mapping to EmergenceMetrics:
      - decision_effort      = 1 - symmetry
      - flow_gradient        = max(d) - min(d)
      - mass_gap             = min(d)
      - spectral_deviation   = |avg(d) - 1|
      - meaning_rank_diff    = edge-order distortion
      - repr_mismatch        = norm spread between pillars
      - noncontractible_loops= triangle inequality slack

    All of these are real numbers from the actual pillar vectors.
    """
    symmetry, distances = compute_symmetry(pillars)

    d12 = distances["P1_P2"]
    d23 = distances["P2_P3"]
    d31 = distances["P3_P1"]

    edge_vals = [d12, d23, d31]
    d_min = min(edge_vals)
    d_max = max(edge_vals)
    d_avg = (d12 + d23 + d31) / 3.0

    # 1) Asymmetry: more asymmetry → more "effort"
    decision_effort = 1.0 - symmetry  # 0 when perfectly equilateral

    # 2) Flow gradient: how uneven the triangle is
    flow_gradient = d_max - d_min

    # 3) Mass gap: weakest edge (smallest connection)
    mass_gap = d_min

    # 4) Spectral deviation: deviation of average edge length from 1.0 scale
    target_len = 1.0
    spectral_deviation = abs(d_avg - target_len)

    # 5) Meaning rank diff: how far sorted order deviates
    sorted_edges = sorted(edge_vals)
    rank_distortion = sum(abs(e - s) for e, s in zip(edge_vals, sorted_edges))
    meaning_rank_diff = rank_distortion

    # 6) Representation mismatch: norm spread between pillar vectors
    norms = []
    for p in [pillars.p1.vector, pillars.p2.vector, pillars.p3.vector]:
        norms.append(sum(x * x for x in p) ** 0.5)
    if norms:
        avg_norm = sum(norms) / len(norms)
        repr_mismatch = sum(abs(n - avg_norm) for n in norms) / len(norms)
    else:
        repr_mismatch = 0.0

    # 7) Noncontractible loops: triangle inequality slack
    #    If any side ≈ sum of the other two, loop is nearly non-contractible.
    slack_1 = abs(d12 + d23 - d31)
    slack_2 = abs(d23 + d31 - d12)
    slack_3 = abs(d31 + d12 - d23)
    noncontractible_loops = min(slack_1, slack_2, slack_3)

    return EmergenceMetrics(
        decision_effort=decision_effort,
        flow_gradient=flow_gradient,
        mass_gap=mass_gap,
        spectral_deviation=spectral_deviation,
        meaning_rank_diff=meaning_rank_diff,
        repr_mismatch=repr_mismatch,
        noncontractible_loops=noncontractible_loops,
    )


def evaluate_geometric_decision(
    decision_id: str,
    pillars: PillarSet,
    cfg: Optional[KeeperConfig] = None,
) -> DecisionEvaluation:
    """Evaluate a decision using ONLY triangle geometry metrics."""
    metrics = compute_metrics_from_geometry(pillars)
    keeper_result = _evaluate_decision(
        decision_id=decision_id,
        pillars=pillars,
        metrics=metrics,
        cfg=cfg,
    )
    return DecisionEvaluation(metrics=metrics, keeper=keeper_result)


# ───────────────────────────────────────────────────────────
#  ConsciousnessKernel-derived metrics (real UEF collapse modes)
# ───────────────────────────────────────────────────────────

async def compute_metrics_from_kernel(
    kernel: Any,
) -> EmergenceMetrics:
    """Derive EmergenceMetrics from the live ConsciousnessKernel.

    This uses existing SAEONYX math:

      - Φ and Soul Vector are already maintained inside `kernel`.
      - `kernel.check_collapse_modes()` returns the 7 ξ-modes:
            consistency
            continuity
            causality
            boundedness
            non_divergence
            moral_alignment
            integrability

    We map those directly into EmergenceMetrics slots:

        decision_effort      ← ξ₁ (consistency)
        flow_gradient        ← ξ₂ (continuity)
        mass_gap             ← ξ₃ (causality)
        spectral_deviation   ← ξ₄ (boundedness)
        meaning_rank_diff    ← ξ₅ (non_divergence)
        repr_mismatch        ← ξ₆ (moral_alignment)
        noncontractible_loops← ξ₇ (integrability)

    Each ξ_k is already in [0,1], with 0 meaning "perfect" and >0 meaning deviation.
    """
    # Import type only at runtime to avoid hard dependency at import time.
    # (This keeps keeper_seven decoupled for testing.)
    modes: Dict[str, float] = await kernel.check_collapse_modes()

    # Provide robust defaults if any key is missing
    def g(key: str) -> float:
        return float(modes.get(key, 0.0))

    decision_effort = g("consistency")
    flow_gradient = g("continuity")
    mass_gap = g("causality")
    spectral_deviation = g("boundedness")
    meaning_rank_diff = g("non_divergence")
    repr_mismatch = g("moral_alignment")
    noncontractible_loops = g("integrability")

    return EmergenceMetrics(
        decision_effort=decision_effort,
        flow_gradient=flow_gradient,
        mass_gap=mass_gap,
        spectral_deviation=spectral_deviation,
        meaning_rank_diff=meaning_rank_diff,
        repr_mismatch=repr_mismatch,
        noncontractible_loops=noncontractible_loops,
    )


async def evaluate_kernel_decision(
    decision_id: str,
    kernel: Any,
    pillars: PillarSet,
    cfg: Optional[KeeperConfig] = None,
) -> DecisionEvaluation:
    """Evaluate a decision using the full ConsciousnessKernel UEF math.

    Flow:
      1. Get real collapse modes Ξ from `kernel.check_collapse_modes()`.
      2. Wrap them into EmergenceMetrics via `compute_metrics_from_kernel`.
      3. Use keeper_of_seven to combine:
           - triangle symmetry / rollability
           - collapse-mode deviations (ξ₁..ξ₇)
      4. Return both raw metrics and KeeperResult.
    """
    metrics = await compute_metrics_from_kernel(kernel)
    keeper_result = _evaluate_decision(
        decision_id=decision_id,
        pillars=pillars,
        metrics=metrics,
        cfg=cfg,
    )
    return DecisionEvaluation(metrics=metrics, keeper=keeper_result)
