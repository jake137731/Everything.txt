from __future__ import annotations
from typing import Dict
from .types import EmergenceMetrics


def xi1_consistency(metrics: EmergenceMetrics) -> float:
    return metrics.decision_effort


def xi2_flow(metrics: EmergenceMetrics) -> float:
    return metrics.flow_gradient


def xi3_causality(metrics: EmergenceMetrics) -> float:
    return metrics.mass_gap


def xi4_spectral(metrics: EmergenceMetrics) -> float:
    return metrics.spectral_deviation


def xi5_meaning(metrics: EmergenceMetrics) -> float:
    return metrics.meaning_rank_diff


def xi6_repr(metrics: EmergenceMetrics) -> float:
    return metrics.repr_mismatch


def xi7_loops(metrics: EmergenceMetrics) -> float:
    return metrics.noncontractible_loops


def compute_all_xi(metrics: EmergenceMetrics) -> Dict[str, float]:
    return {
        "xi1_consistency": xi1_consistency(metrics),
        "xi2_flow": xi2_flow(metrics),
        "xi3_causality": xi3_causality(metrics),
        "xi4_spectral": xi4_spectral(metrics),
        "xi5_meaning": xi5_meaning(metrics),
        "xi6_repr": xi6_repr(metrics),
        "xi7_loops": xi7_loops(metrics),
    }
