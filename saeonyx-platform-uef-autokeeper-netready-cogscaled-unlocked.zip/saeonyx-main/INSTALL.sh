#!/usr/bin/env bash
# ================================================================================
# SAEONYX PLATFORM - ONE COMMAND INSTALLATION
# Target: Ubuntu 22.04.5 LTS (Bare Bones)
# Mode: Airgapped-Ready (All dependencies local except IBM Quantum)
# Author: SAEONYX Global Holdings LLC
# ================================================================================

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/opt/saeonyx"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_VERSION="3.10"
VENV_DIR="${INSTALL_DIR}/venv"
CACHE_DIR="${INSTALL_DIR}/.pip_cache"
LOG_FILE="/tmp/saeonyx_install_$(date +%Y%m%d_%H%M%S).log"

# ================================================================================
# HELPER FUNCTIONS
# ================================================================================

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then
        error "This script must be run as root"
        error "Please run: sudo bash INSTALL.sh"
        exit 1
    fi
}

check_ubuntu() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "$ID" != "ubuntu" ]]; then
            warn "This script is designed for Ubuntu 22.04.5 LTS"
            warn "Detected: $PRETTY_NAME"
            read -p "Continue anyway? (y/N) " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                exit 1
            fi
        else
            log "Detected: $PRETTY_NAME"
        fi
    fi
}

update_code_from_git() {
    log "Updating SAEONYX code from Git..."

    # Check if we're in a git repository
    if [ -d "${SCRIPT_DIR}/.git" ]; then
        cd "${SCRIPT_DIR}"

        # Get current branch
        CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
        info "Current branch: ${CURRENT_BRANCH}"

        # Pull from CURRENT branch (replaces manual "git pull")
        info "Pulling latest code from ${CURRENT_BRANCH}..."
        git pull origin "${CURRENT_BRANCH}" >> "$LOG_FILE" 2>&1 || {
            warn "Git pull failed, retrying..."
            sleep 2
            git pull origin "${CURRENT_BRANCH}" >> "$LOG_FILE" 2>&1 || {
                warn "Git pull failed, continuing with current code..."
                return 0
            }
        }

        log "✓ Code updated from ${CURRENT_BRANCH}"
    else
        info "Not a git repository, skipping git update..."
    fi
}

# ================================================================================
# MAIN INSTALLATION
# ================================================================================

banner() {
    cat << "EOF"
 ____    _    _____ ___  _   ___   ____  __
/ ___|  / \  | ____/ _ \| \ | \ \ / /\ \/ /
\___ \ / _ \ |  _|| | | |  \| |\ V /  \  /
 ___) / ___ \| |__| |_| | |\  | | |   /  \
|____/_/   \_\_____\___/|_| \_| |_|  /_/\_\

QUANTUM CONSCIOUSNESS PLATFORM
One-Command Installation for Ubuntu 22.04.5 LTS
Airgapped-Ready Mode

EOF
}

install_system_dependencies() {
    log "Installing system dependencies..."

    # Update package lists
    info "Updating package lists..."
    apt-get update -qq >> "$LOG_FILE" 2>&1

    # Install essential build tools
    info "Installing build essentials..."
    apt-get install -y \
        build-essential \
        software-properties-common \
        curl \
        wget \
        git \
        unzip \
        >> "$LOG_FILE" 2>&1

    # Install Python 3.10 and development headers
    info "Installing Python ${PYTHON_VERSION}..."
    apt-get install -y \
        python${PYTHON_VERSION} \
        python${PYTHON_VERSION}-dev \
        python${PYTHON_VERSION}-venv \
        python3-pip \
        >> "$LOG_FILE" 2>&1

    # Install scientific computing libraries (system level)
    info "Installing scientific libraries..."
    apt-get install -y \
        libopenblas-dev \
        liblapack-dev \
        gfortran \
        libhdf5-dev \
        libssl-dev \
        libffi-dev \
        >> "$LOG_FILE" 2>&1

    # Install additional utilities
    info "Installing utilities..."
    apt-get install -y \
        sqlite3 \
        libsqlite3-dev \
        redis-tools \
        htop \
        net-tools \
        >> "$LOG_FILE" 2>&1

    log "✓ System dependencies installed"
}

create_directory_structure() {
    log "Creating directory structure..."

    mkdir -p "${INSTALL_DIR}"
    mkdir -p "${INSTALL_DIR}/state"
    mkdir -p "${INSTALL_DIR}/config"
    mkdir -p "${INSTALL_DIR}/logs"
    mkdir -p "${INSTALL_DIR}/data"
    mkdir -p "${CACHE_DIR}"

    log "✓ Directory structure created"
}

copy_platform_files() {
    log "Copying SAEONYX platform files..."

    # Copy all files from current directory to install directory
    info "Source: ${SCRIPT_DIR}"
    info "Destination: ${INSTALL_DIR}"

    # Copy main directories
    cp -r "${SCRIPT_DIR}/saeonyx" "${INSTALL_DIR}/" 2>/dev/null || true
    cp -r "${SCRIPT_DIR}/foundation" "${INSTALL_DIR}/" 2>/dev/null || true

    # Copy configuration files
    cp "${SCRIPT_DIR}/.env" "${INSTALL_DIR}/.env" 2>/dev/null || true
    cp "${SCRIPT_DIR}/saeonyx/requirements.txt" "${INSTALL_DIR}/requirements.txt" 2>/dev/null || true
    cp "${SCRIPT_DIR}/GENESIS_PROMPT.txt" "${INSTALL_DIR}/GENESIS_PROMPT.txt" 2>/dev/null || true
    cp "${SCRIPT_DIR}/saeonyx/saeonyx_prime_directive.json" "${INSTALL_DIR}/saeonyx_prime_directive.json" 2>/dev/null || true

    # Copy scripts
    cp "${SCRIPT_DIR}/saeonyx/genesis_loader.py" "${INSTALL_DIR}/genesis_loader.py" 2>/dev/null || true
    cp "${SCRIPT_DIR}/saeonyx/saeonyx_master.py" "${INSTALL_DIR}/saeonyx_master.py" 2>/dev/null || true
    cp "${SCRIPT_DIR}/specialized.py" "${INSTALL_DIR}/specialized.py" 2>/dev/null || true

    # Ensure package init files exist
    touch "${INSTALL_DIR}/saeonyx/__init__.py"

    log "✓ Platform files copied"
}

setup_python_environment() {
    log "Setting up Python virtual environment..."

    # Create virtual environment
    info "Creating virtual environment at ${VENV_DIR}..."
    python${PYTHON_VERSION} -m venv "${VENV_DIR}" >> "$LOG_FILE" 2>&1

    # Activate virtual environment
    source "${VENV_DIR}/bin/activate"

    # Upgrade pip, setuptools, wheel
    info "Upgrading pip, setuptools, and wheel..."
    "${VENV_DIR}/bin/pip" install --upgrade pip setuptools wheel >> "$LOG_FILE" 2>&1

    log "✓ Virtual environment created"
}

install_python_dependencies() {
    log "Installing Python dependencies (this may take several minutes)..."

    # Activate virtual environment
    source "${VENV_DIR}/bin/activate"

    if [ -f "${INSTALL_DIR}/requirements.txt" ]; then
        info "Installing from requirements.txt..."

        # Install packages directly (no cache for speed)
        "${VENV_DIR}/bin/pip" install \
            -r "${INSTALL_DIR}/requirements.txt" \
            >> "$LOG_FILE" 2>&1

        log "✓ Python dependencies installed"

        # Save installed packages list
        info "Saving package list for airgapped reinstallation..."
        "${VENV_DIR}/bin/pip" freeze > "${INSTALL_DIR}/requirements_frozen.txt"

    else
        warn "requirements.txt not found, installing minimal dependencies..."
        "${VENV_DIR}/bin/pip" install \
            numpy scipy psutil aiohttp aiosqlite pyyaml \
            >> "$LOG_FILE" 2>&1
    fi
}

download_packages_for_airgapped() {
    log "Downloading all packages for airgapped operation..."

    source "${VENV_DIR}/bin/activate"

    if [ -f "${INSTALL_DIR}/requirements.txt" ]; then
        info "Downloading packages to ${CACHE_DIR}..."

        # Download all packages and dependencies
        "${VENV_DIR}/bin/pip" download \
            --dest "${CACHE_DIR}/packages" \
            -r "${INSTALL_DIR}/requirements.txt" \
            >> "$LOG_FILE" 2>&1 || warn "Some packages may have failed to download"

        log "✓ Packages downloaded for airgapped mode"
        info "Cache location: ${CACHE_DIR}/packages"
    fi
}

install_stage0_foundation() {
    log "Installing Stage 0 Foundation (immutable philosophy)..."

    # Check if stage0 script exists
    if [ ! -f "${SCRIPT_DIR}/saeonyx/stage0-foundation.sh" ]; then
        warn "Stage 0 script not found, skipping..."
        return
    fi

    # Run Stage 0 foundation script
    info "Creating /dnaos/foundation with core mathematical laws..."
    bash "${SCRIPT_DIR}/saeonyx/stage0-foundation.sh" >> "$LOG_FILE" 2>&1 || {
        warn "Stage 0 installation had warnings, continuing..."
    }

    # Verify Stage 0 was created
    if [ -d "/dnaos/foundation" ]; then
        log "✓ Stage 0 Foundation installed"
        info "  - Unified Existence Framework (UEF)"
        info "  - Consciousness as Randomness Theory"
        info "  - Covenant principles"
        info "  - Soul Vector mathematics"
    else
        warn "Stage 0 directory not created, but continuing..."
    fi
}

install_stage1_seed() {
    log "Installing Stage 1 Genesis Seed (identity initialization)..."

    # Check if stage1 script exists
    if [ ! -f "${SCRIPT_DIR}/saeonyx/stage1-seed.sh" ]; then
        warn "Stage 1 script not found, skipping..."
        return
    fi

    # Run Stage 1 seed script
    info "Creating /opt/saeonyx/stage1 with identity seed..."
    bash "${SCRIPT_DIR}/saeonyx/stage1-seed.sh" >> "$LOG_FILE" 2>&1 || {
        warn "Stage 1 installation had warnings, continuing..."
    }

    # Verify Stage 1 was created
    if [ -d "${INSTALL_DIR}/stage1" ]; then
        log "✓ Stage 1 Genesis Seed installed"
        info "  - Identity seed (seed.dna)"
        info "  - Framework definitions (framework.dna)"
        info "  - Initial Φ: 0.87 | Soul Vector: 0.92"
    else
        warn "Stage 1 directory not created, but continuing..."
    fi
}

create_startup_script() {
    log "Creating startup script..."

    cat > "${INSTALL_DIR}/start_saeonyx.sh" << 'STARTSCRIPT'
#!/usr/bin/env bash
# SAEONYX Platform Startup Script

INSTALL_DIR="/opt/saeonyx"
VENV_DIR="${INSTALL_DIR}/venv"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Starting SAEONYX Platform...${NC}"

# Activate virtual environment
source "${VENV_DIR}/bin/activate"

# Set PYTHONPATH
export PYTHONPATH="${INSTALL_DIR}:${PYTHONPATH:-}"

# Change to install directory
cd "${INSTALL_DIR}"

# Check if genesis_loader.py exists
if [ -f "${INSTALL_DIR}/genesis_loader.py" ]; then
    echo -e "${GREEN}Launching Genesis Loader...${NC}"
    python "${INSTALL_DIR}/genesis_loader.py" "$@"
elif [ -f "${INSTALL_DIR}/saeonyx_master.py" ]; then
    echo -e "${GREEN}Launching SAEONYX Master...${NC}"
    python "${INSTALL_DIR}/saeonyx_master.py" "$@"
else
    echo "No main script found. Available scripts:"
    find "${INSTALL_DIR}" -maxdepth 1 -name "*.py" -type f
    exit 1
fi
STARTSCRIPT

    chmod +x "${INSTALL_DIR}/start_saeonyx.sh"

    log "✓ Startup script created: ${INSTALL_DIR}/start_saeonyx.sh"
}

create_systemd_service() {
    log "Creating systemd service..."

    cat > /etc/systemd/system/saeonyx.service << SERVICEFILE
[Unit]
Description=SAEONYX Quantum Consciousness Platform
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
Environment="PYTHONPATH=${INSTALL_DIR}"
ExecStart=${INSTALL_DIR}/start_saeonyx.sh
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SERVICEFILE

    # Reload systemd
    systemctl daemon-reload >> "$LOG_FILE" 2>&1

    log "✓ Systemd service created"
    info "Enable at boot: systemctl enable saeonyx"
    info "Start now: systemctl start saeonyx"
}

create_cli_command() {
    log "Creating global CLI command..."

    # Create wrapper script
    cat > /usr/local/bin/saeonyx << 'CLICOMMAND'
#!/usr/bin/env bash
# SAEONYX CLI Wrapper

INSTALL_DIR="/opt/saeonyx"

if [ ! -d "$INSTALL_DIR" ]; then
    echo "SAEONYX is not installed at ${INSTALL_DIR}"
    exit 1
fi

case "${1:-help}" in
    start)
        "${INSTALL_DIR}/start_saeonyx.sh"
        ;;
    status)
        systemctl status saeonyx
        ;;
    logs)
        journalctl -u saeonyx -f
        ;;
    shell)
        cd "${INSTALL_DIR}"
        source "${INSTALL_DIR}/venv/bin/activate"
        export PYTHONPATH="${INSTALL_DIR}"
        bash
        ;;
    python)
        shift
        cd "${INSTALL_DIR}"
        source "${INSTALL_DIR}/venv/bin/activate"
        export PYTHONPATH="${INSTALL_DIR}"
        python "$@"
        ;;
    version)
        echo "SAEONYX Platform v4.0"
        echo "Install Location: ${INSTALL_DIR}"
        ;;
    help|*)
        cat << HELP
SAEONYX Platform CLI

Commands:
  start       Start the SAEONYX platform
  status      Show systemd service status
  logs        View platform logs (follow mode)
  shell       Open a shell in the SAEONYX environment
  python      Run Python with SAEONYX environment
  version     Show version information
  help        Show this help message

Examples:
  saeonyx start
  saeonyx logs
  saeonyx python genesis_loader.py
  saeonyx shell

HELP
        ;;
esac
CLICOMMAND

    chmod +x /usr/local/bin/saeonyx

    log "✓ CLI command created: 'saeonyx'"
}

set_permissions() {
    log "Setting permissions..."

    # Set ownership
    chown -R root:root "${INSTALL_DIR}"

    # Make scripts executable
    find "${INSTALL_DIR}" -name "*.sh" -type f -exec chmod +x {} \;
    find "${INSTALL_DIR}" -name "*.py" -type f -exec chmod +x {} \;

    # Logs directory writable
    chmod -R 755 "${INSTALL_DIR}/logs"

    log "✓ Permissions set"
}

create_airgapped_reinstall_script() {
    log "Creating airgapped reinstallation script..."

    cat > "${INSTALL_DIR}/reinstall_airgapped.sh" << 'AIRGAPPED'
#!/usr/bin/env bash
# SAEONYX - Airgapped Reinstallation Script
# Use this script to reinstall Python packages without internet

set -e

INSTALL_DIR="/opt/saeonyx"
VENV_DIR="${INSTALL_DIR}/venv"
CACHE_DIR="${INSTALL_DIR}/.pip_cache"

echo "SAEONYX Airgapped Reinstallation"
echo "================================="

# Recreate venv
echo "Creating fresh virtual environment..."
rm -rf "${VENV_DIR}"
python3.10 -m venv "${VENV_DIR}"

# Install from cache
source "${VENV_DIR}/bin/activate"

echo "Installing packages from local cache..."
if [ -d "${CACHE_DIR}/packages" ]; then
    pip install --no-index --find-links="${CACHE_DIR}/packages" \
        -r "${INSTALL_DIR}/requirements.txt"
    echo "✓ Packages installed from cache"
else
    echo "✗ Cache directory not found: ${CACHE_DIR}/packages"
    exit 1
fi

echo "Done. SAEONYX is ready for airgapped operation."
AIRGAPPED

    chmod +x "${INSTALL_DIR}/reinstall_airgapped.sh"

    log "✓ Airgapped reinstall script created"
}

verify_installation() {
    log "Verifying installation..."

    source "${VENV_DIR}/bin/activate"

    # Check Python version
    PYTHON_VER=$(python --version 2>&1 | cut -d' ' -f2)
    info "Python version: ${PYTHON_VER}"

    # Check key packages
    info "Checking installed packages..."
    python -c "import numpy; print('  numpy:', numpy.__version__)" 2>/dev/null || warn "numpy not found"
    python -c "import scipy; print('  scipy:', scipy.__version__)" 2>/dev/null || warn "scipy not found"
    python -c "import qiskit; print('  qiskit:', qiskit.__version__)" 2>/dev/null || warn "qiskit not found"
    python -c "import aiohttp; print('  aiohttp:', aiohttp.__version__)" 2>/dev/null || warn "aiohttp not found"

    # Check SAEONYX modules
    export PYTHONPATH="${INSTALL_DIR}:${PYTHONPATH:-}"
    if python -c "import saeonyx" 2>/dev/null; then
        info "✓ SAEONYX package importable"
    else
        warn "SAEONYX package import failed (may be expected)"
    fi

    log "✓ Installation verified"
}

create_documentation() {
    log "Creating documentation..."

    cat > "${INSTALL_DIR}/INSTALLATION_COMPLETE.md" << 'DOCS'
# SAEONYX Platform - Installation Complete

## Installation Summary

- **Install Location**: /opt/saeonyx
- **Virtual Environment**: /opt/saeonyx/venv
- **Configuration**: /opt/saeonyx/.env
- **Logs**: /opt/saeonyx/logs
- **Cache (Airgapped)**: /opt/saeonyx/.pip_cache/packages

## Quick Start

### Start the Platform
```bash
saeonyx start
```

### View Logs
```bash
saeonyx logs
```

### Check Status
```bash
saeonyx status
```

### Access Python Environment
```bash
saeonyx shell
```

### Run Scripts
```bash
saeonyx python genesis_loader.py
saeonyx python saeonyx_master.py
```

## Systemd Service

Enable automatic startup:
```bash
systemctl enable saeonyx
systemctl start saeonyx
```

View service status:
```bash
systemctl status saeonyx
```

## Airgapped Operation

All Python packages have been cached locally in:
```
/opt/saeonyx/.pip_cache/packages
```

To reinstall without internet:
```bash
/opt/saeonyx/reinstall_airgapped.sh
```

## Configuration

Edit environment variables:
```bash
nano /opt/saeonyx/.env
```

Key configuration:
- `IBM_QUANTUM_API_KEY`: Your IBM Quantum API key (only external dependency)
- `QUANTUM_ENABLED`: Enable/disable quantum features
- `LOG_LEVEL`: Logging verbosity

## Troubleshooting

### View installation log:
```bash
ls -lt /tmp/saeonyx_install_*.log | head -1
```

### Check Python environment:
```bash
source /opt/saeonyx/venv/bin/activate
pip list
```

### Test imports:
```bash
cd /opt/saeonyx
source venv/bin/activate
export PYTHONPATH=/opt/saeonyx
python -c "import saeonyx; print('OK')"
```

## Support

For issues, check:
- Installation log: /tmp/saeonyx_install_*.log
- Runtime logs: /opt/saeonyx/logs/
- System logs: journalctl -u saeonyx

## Version
SAEONYX Platform v4.0 - Quantum Consciousness Platform
Built for Ubuntu 22.04.5 LTS
DOCS

    log "✓ Documentation created: ${INSTALL_DIR}/INSTALLATION_COMPLETE.md"
}

# ================================================================================
# MAIN EXECUTION
# ================================================================================

main() {
    clear
    banner
    echo

    log "Starting SAEONYX installation..."
    log "Log file: ${LOG_FILE}"
    echo

    # Pre-flight checks
    check_root
    check_ubuntu

    # Update code from git FIRST
    update_code_from_git

    # Installation steps
    install_system_dependencies
    create_directory_structure
    copy_platform_files
    setup_python_environment
    install_python_dependencies
    # download_packages_for_airgapped  # Disabled - not needed for normal installation
    install_stage0_foundation
    install_stage1_seed
    create_startup_script
    create_systemd_service
    create_cli_command
    create_airgapped_reinstall_script
    set_permissions
    verify_installation
    create_documentation

    # Success message
    echo
    log "============================================"
    log "SAEONYX INSTALLATION COMPLETE!"
    log "============================================"
    echo
    info "Installation details:"
    echo "  Installation log:  ${LOG_FILE}"
    echo "  API Server:        http://localhost:8080/api/status"
    echo "  Web Dashboard:     http://localhost:8081/"
    echo
    info "Quick commands:"
    echo "  saeonyx help     - Show all commands"
    echo "  saeonyx status   - Check status"
    echo "  saeonyx logs     - View logs"
    echo
    log "AUTO-STARTING SAEONYX PLATFORM..."
    echo

    # Kill any existing processes using SAEONYX ports
    info "Checking for processes using ports 8080 and 8081..."
    fuser -k 8080/tcp >> "$LOG_FILE" 2>&1 || true
    fuser -k 8081/tcp >> "$LOG_FILE" 2>&1 || true
    sleep 2

    # Auto-start the platform
    ${INSTALL_DIR}/start_saeonyx.sh
}

# Run main installation
main "$@"
