#!/usr/bin/env bash
# =========================================================
# SAEONYX : FULL PLATFORM INSTALLER
# Target : /opt/saeonyx
# Author : Jake McDonough (SAEONYX Global Holdings LLC)
# =========================================================

set -euo pipefail

ZIP_PATH="${1:-$HOME/Downloads/saeonyx_full_modules_from_commits.zip}"
SAEONYX_ROOT="/opt/saeonyx"

echo ">>> SAEONYX INSTALLER"
echo ">>> ZIP:  ${ZIP_PATH}"
echo ">>> ROOT: ${SAEONYX_ROOT}"
echo

if [ ! -f "$ZIP_PATH" ]; then
  echo "❌ ZIP not found at: $ZIP_PATH"
  echo "   Pass the path explicitly, e.g.:"
  echo "   sudo bash install_saeonyx.sh /path/to/saeonyx_full_modules_from_commits.zip"
  exit 1
fi

# 1. Require root (because we’re touching /opt)
if [ "$EUID" -ne 0 ]; then
  echo "❌ Please run as root: sudo bash install_saeonyx.sh ..."
  exit 1
fi

# 2. Create base directories
echo ">>> Creating directory structure under ${SAEONYX_ROOT}..."
mkdir -p "${SAEONYX_ROOT}"
mkdir -p "${SAEONYX_ROOT}/state"
mkdir -p "${SAEONYX_ROOT}/config"
mkdir -p "${SAEONYX_ROOT}/foundation"

# 3. Unzip code into /opt/saeonyx
echo ">>> Unzipping code into ${SAEONYX_ROOT}..."
unzip -o "$ZIP_PATH" -d "${SAEONYX_ROOT}" >/tmp/saeonyx_unzip.log 2>&1 || {
  echo "❌ unzip failed. Check /tmp/saeonyx_unzip.log"
  exit 1
}

# Ensure package root
if [ ! -f "${SAEONYX_ROOT}/saeonyx/__init__.py" ]; then
  echo ">>> Creating missing package root __init__.py..."
  touch "${SAEONYX_ROOT}/saeonyx/__init__.py"
fi

# 4. Optional: Python virtualenv
PYTHON_BIN="$(command -v python3 || true)"
if [ -z "$PYTHON_BIN" ]; then
  echo "⚠️  python3 not found; skipping venv creation."
else
  echo ">>> Setting up Python venv under ${SAEONYX_ROOT}/venv ..."
  "$PYTHON_BIN" -m venv "${SAEONYX_ROOT}/venv" || echo "⚠️  venv creation failed, continuing without."
  if [ -f "${SAEONYX_ROOT}/venv/bin/pip" ]; then
    source "${SAEONYX_ROOT}/venv/bin/activate"
    if [ -f "${SAEONYX_ROOT}/requirements.txt" ]; then
      echo ">>> Installing requirements from requirements.txt..."
      pip install -r "${SAEONYX_ROOT}/requirements.txt" || echo "⚠️  requirements install failed; check manually."
    else
      echo ">>> No requirements.txt found; you can install deps manually."
    fi
    deactivate || true
  fi
fi

# 5. Install genesis_loader.py if not present
if [ ! -f "${SAEONYX_ROOT}/genesis_loader.py" ]; then
  echo ">>> WARNING: genesis_loader.py not found in ${SAEONYX_ROOT}."
  echo "    Make sure you copy the Genesis Loader script we built into:"
  echo "    ${SAEONYX_ROOT}/genesis_loader.py"
else
  chmod +x "${SAEONYX_ROOT}/genesis_loader.py"
fi

# 6. Stage 0 and Genesis prompt existence checks
if [ ! -f "${SAEONYX_ROOT}/foundation/STAGE0_PRIME_DIRECTIVE.md" ]; then
  echo "⚠️  STAGE0_PRIME_DIRECTIVE.md missing."
  echo "    Run your Stage 0 installer script to create the Prime Directive charter."
fi

if [ ! -f "${SAEONYX_ROOT}/saeonyx_prime_directive.json" ]; then
  echo "⚠️  saeonyx_prime_directive.json missing."
  echo "    Create it from the SAEONYX_PRIME_DIRECTIVE Python dict we defined earlier."
fi

if [ ! -f "${SAEONYX_ROOT}/GENESIS_PROMPT.txt" ]; then
  echo "⚠️  GENESIS_PROMPT.txt missing."
  echo "    Create it using the Genesis Prompt text we defined and save it here."
fi

echo
echo ">>> SAEONYX code installation complete."
echo ">>> Next steps (once Stage 0 + JSON + Genesis prompt are in place):"
echo "    sudo ${SAEONYX_ROOT}/genesis_loader.py"
echo
echo "Done."