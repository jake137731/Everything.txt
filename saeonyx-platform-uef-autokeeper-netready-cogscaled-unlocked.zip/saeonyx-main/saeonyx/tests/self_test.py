#!/usr/bin/env python3
# =========================================================
# SAEONYX : SELF-TEST SUITE
# Purpose : Quick integrity + configuration check
# Target  : /opt/saeonyx environment
# =========================================================

import json
import os
import stat
from datetime import datetime
from pathlib import Path

RESULT = {
    "timestamp": None,
    "root": None,
    "checks": [],
    "status": "UNKNOWN",
}


def record(name, ok, detail=""):
    RESULT["checks"].append(
        {
            "name": name,
            "ok": bool(ok),
            "detail": detail,
        }
    )


def check_paths(root: Path):
    record("root_exists", root.exists(), f"{root}")
    for sub in ["saeonyx", "foundation", "config", "state"]:
        p = root / sub
        record(f"dir_{sub}_exists", p.exists(), f"{p}")


def check_stage0(root: Path):
    charter = root / "foundation" / "STAGE0_PRIME_DIRECTIVE.md"
    if not charter.exists():
        record("stage0_charter_exists", False, f"{charter} missing")
        return

    record("stage0_charter_exists", True, f"{charter}")

    try:
        st = charter.stat()
        # World-writable bit?
        world_writable = bool(st.st_mode & stat.S_IWOTH)
        if world_writable:
            record("stage0_charter_permissions", False, "World-writable; should be locked down.")
        else:
            record("stage0_charter_permissions", True, oct(st.st_mode))
    except Exception as e:
        record("stage0_charter_permissions", False, f"Stat failed: {e}")

    try:
        with charter.open("r", encoding="utf-8") as f:
            head = "".join(f.readlines()[:5])
        record("stage0_charter_readable", True, head.strip())
    except Exception as e:
        record("stage0_charter_readable", False, f"Read failed: {e}")


def check_genesis_prompt(root: Path):
    prompt = root / "GENESIS_PROMPT.txt"
    if not prompt.exists():
        record("genesis_prompt_exists", False, f"{prompt} missing")
        return
    record("genesis_prompt_exists", True, f"{prompt}")
    try:
        with prompt.open("r", encoding="utf-8") as f:
            head = "".join(f.readlines()[:5])
        record("genesis_prompt_readable", True, head.strip())
    except Exception as e:
        record("genesis_prompt_readable", False, f"Read failed: {e}")


def check_prime_json(root: Path):
    prime = root / "config" / "saeonyx_prime_directive.json"
    if not prime.exists():
        record("prime_json_exists", False, f"{prime} missing (not fatal but recommended)")
        return

    record("prime_json_exists", True, f"{prime}")
    try:
        with prime.open("r", encoding="utf-8") as f:
            data = json.load(f)
        ident = data.get("identity", {})
        record("prime_json_parsable", True, f"identity={ident}")
    except Exception as e:
        record("prime_json_parsable", False, f"JSON parse failed: {e}")


def check_python_package(root: Path):
    # ensure /opt/saeonyx is on sys.path
    import sys

    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

    try:
        import saeonyx  # type: ignore

        record("import_saeonyx", True, f"Loaded module: {saeonyx.__file__}")
    except Exception as e:
        record("import_saeonyx", False, f"Import failed: {e}")
        return

    # Probe for a bootstrap entrypoint, but DO NOT execute fully
    try:
        bootstrap = getattr(saeonyx, "bootstrap", None)
        if callable(bootstrap):
            record("bootstrap_entrypoint_present", True, "saeonyx.bootstrap() is callable.")
        else:
            record("bootstrap_entrypoint_present", False, "No saeonyx.bootstrap() found (not fatal).")
    except Exception as e:
        record("bootstrap_entrypoint_present", False, f"Error checking bootstrap: {e}")


def main():
    root = Path(os.environ.get("SAEONYX_ROOT", "/opt/saeonyx")).resolve()
    RESULT["timestamp"] = datetime.utcnow().isoformat() + "Z"
    RESULT["root"] = str(root)

    check_paths(root)
    check_stage0(root)
    check_genesis_prompt(root)
    check_prime_json(root)
    check_python_package(root)

    # overall status
    if all(c["ok"] for c in RESULT["checks"] if c["name"].startswith(("root_", "dir_", "stage0_", "genesis_", "import_"))):
        RESULT["status"] = "PASS"
    else:
        RESULT["status"] = "WARN"

    # write to SELF_TEST.log under /opt/saeonyx/state/
    state_dir = root / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    log_file = state_dir / "SELF_TEST.log"

    try:
        with log_file.open("a", encoding="utf-8") as f:
            f.write("# SELF-TEST RUN\n")
            json.dump(RESULT, f, indent=2)
            f.write("\n\n")
        print(f"Self-test complete. Status={RESULT['status']}. Logged to {log_file}")
    except Exception as e:
        print(f"Self-test complete, but failed to write log: {e}")
        print(json.dumps(RESULT, indent=2))


if __name__ == "__main__":
    main()