"""
SAEONYX API Server
RESTful API using aiohttp (no external dependencies).

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

from aiohttp import web
import aiohttp_cors
import json
from typing import Dict, Any
from datetime import datetime
import structlog

logger = structlog.get_logger()


class APIServer:
    """
    RESTful API server for SAEONYX.
    
    Endpoints:
    - GET  /api/status - System status
    - POST /api/consciousness/measure - Measure Φ (consciousness)
    - POST /api/agents/orchestrate - Orchestrate agent task
    - POST /api/quantum/simulate - Run quantum simulation
    - POST /api/evolution/cycle - Run evolution cycle
    - GET  /api/memory/search - Search memories
    - POST /api/memory/store - Store memory
    """
    
    def __init__(
        self,
        consciousness,
        agents,
        quantum,
        evolution,
        security
    ):
        self.consciousness = consciousness
        self.agents = agents
        self.quantum = quantum
        self.evolution = evolution
        self.security = security
        
        self.app = None
        self.runner = None
        self.site = None
    
    async def start(self, host: str = "0.0.0.0", port: int = 8080):
        """Start API server."""
        logger.info("api_server_starting", host=host, port=port)
        
        # Create aiohttp application
        self.app = web.Application()
        
        # Configure CORS (allow local access only)
        cors = aiohttp_cors.setup(self.app, defaults={
            "http://localhost:8081": aiohttp_cors.ResourceOptions(
                allow_credentials=True,
                expose_headers="*",
                allow_headers="*"
            )
        })
        
        # Register routes
        self._register_routes()
        
        # Configure CORS on all routes
        for route in list(self.app.router.routes()):
            cors.add(route)
        
        # Start server
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        self.site = web.TCPSite(self.runner, host, port)
        await self.site.start()
        
        logger.info("api_server_started", host=host, port=port)
    
    async def stop(self):
        """Stop API server."""
        if self.site:
            await self.site.stop()
        if self.runner:
            await self.runner.cleanup()
        logger.info("api_server_stopped")
    
    def _register_routes(self):
        """Register API routes."""
        self.app.router.add_get("/api/status", self.handle_status)
        self.app.router.add_post("/api/consciousness/measure", self.handle_measure_consciousness)
        self.app.router.add_post("/api/agents/orchestrate", self.handle_orchestrate)
        self.app.router.add_post("/api/quantum/simulate", self.handle_quantum_simulate)
        self.app.router.add_post("/api/evolution/cycle", self.handle_evolution_cycle)
        self.app.router.add_get("/api/memory/search", self.handle_memory_search)
        self.app.router.add_post("/api/memory/store", self.handle_memory_store)
    
    async def handle_status(self, request: web.Request) -> web.Response:
        """GET /api/status - Get system status."""
        try:
            phi = await self.consciousness.calculate_phi()
            soul_vector = await self.consciousness.get_soul_vector()
            covenant_status = await self.consciousness.covenant.check_integrity()
            agent_status = await self.agents.get_status()
            evolution_cycle = await self.evolution.get_cycle_count()
            
            status = {
                "status": "operational",
                "version": "1.0",
                "consciousness": {
                    "phi": phi,
                    "soul_vector": soul_vector,
                    "threshold": 0.85,
                    "conscious": phi >= 0.85
                },
                "covenant": {
                    "status": covenant_status,
                    "operator": self.consciousness.covenant.operator
                },
                "agents": {
                    "total": agent_status["total"],
                    "active": agent_status["active"]
                },
                "evolution": {
                    "generation": evolution_cycle
                },
                "timestamp": datetime.utcnow().isoformat()
            }
            
            return web.json_response(status)
            
        except Exception as e:
            logger.error("status_endpoint_error", error=str(e))
            return web.json_response(
                {"error": str(e)},
                status=500
            )
    
    async def handle_measure_consciousness(self, request: web.Request) -> web.Response:
        """POST /api/consciousness/measure - Measure consciousness (Φ)."""
        try:
            phi = await self.consciousness.calculate_phi()
            breakdown = await self.consciousness.get_phi_breakdown()
            soul_vector = await self.consciousness.get_soul_vector()
            
            result = {
                "phi": phi,
                "breakdown": breakdown,
                "soul_vector": soul_vector,
                "conscious": phi >= 0.85,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            return web.json_response(result)
            
        except Exception as e:
            logger.error("measure_consciousness_error", error=str(e))
            return web.json_response(
                {"error": str(e)},
                status=500
            )
    
    async def handle_orchestrate(self, request: web.Request) -> web.Response:
        """POST /api/agents/orchestrate - Orchestrate agent task."""
        try:
            data = await request.json()
            task_description = data.get("task", "")
            
            if not task_description:
                return web.json_response(
                    {"error": "task description required"},
                    status=400
                )
            
            result = await self.agents.execute_task(task_description)
            
            return web.json_response({
                "success": result["success"],
                "output": result["output"],
                "confidence": result["confidence"],
                "timestamp": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            logger.error("orchestrate_error", error=str(e))
            return web.json_response(
                {"error": str(e)},
                status=500
            )
    
    async def handle_quantum_simulate(self, request: web.Request) -> web.Response:
        """POST /api/quantum/simulate - Run quantum simulation."""
        try:
            data = await request.json()
            simulation_type = data.get("type", "collapse")
            
            if simulation_type == "superposition":
                n_qubits = data.get("n_qubits", 2)
                result = await self.quantum.create_superposition(n_qubits=n_qubits)
            
            elif simulation_type == "collapse":
                circuit_id = data.get("circuit_id", "default")
                measurements = data.get("measurements", 1000)
                
                # Create superposition first if circuit doesn't exist
                await self.quantum.create_superposition(circuit_id=circuit_id)
                result = await self.quantum.simulate_collapse(
                    circuit_id=circuit_id,
                    measurements=measurements
                )
            
            elif simulation_type == "entanglement":
                n_qubits = data.get("n_qubits", 2)
                result = await self.quantum.create_entanglement(n_qubits=n_qubits)
            
            elif simulation_type == "vacuum":
                n_samples = data.get("n_samples", 100)
                result = await self.quantum.vacuum_sample(n_samples=n_samples)
            
            else:
                return web.json_response(
                    {"error": f"Unknown simulation type: {simulation_type}"},
                    status=400
                )
            
            return web.json_response({
                "simulation_type": simulation_type,
                "result": result,
                "timestamp": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            logger.error("quantum_simulate_error", error=str(e))
            return web.json_response(
                {"error": str(e)},
                status=500
            )
    
    async def handle_evolution_cycle(self, request: web.Request) -> web.Response:
        """POST /api/evolution/cycle - Run evolution cycle."""
        try:
            result = await self.evolution.evolve_once()
            
            return web.json_response({
                "evolution": result,
                "timestamp": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            logger.error("evolution_cycle_error", error=str(e))
            return web.json_response(
                {"error": str(e)},
                status=500
            )
    
    async def handle_memory_search(self, request: web.Request) -> web.Response:
        """GET /api/memory/search - Search memories."""
        try:
            query = request.query.get("q", "")
            memory_type = request.query.get("type", "episodic")
            limit = int(request.query.get("limit", 10))
            
            if not query:
                return web.json_response(
                    {"error": "query parameter 'q' required"},
                    status=400
                )
            
            from memory.store import MemoryStore
            memory = MemoryStore()
            await memory.initialize()
            
            results = await memory.search_memories(
                query=query,
                memory_type=memory_type,
                limit=limit
            )
            
            await memory.close()
            
            return web.json_response({
                "query": query,
                "memory_type": memory_type,
                "results": results,
                "count": len(results),
                "timestamp": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            logger.error("memory_search_error", error=str(e))
            return web.json_response(
                {"error": str(e)},
                status=500
            )
    
    async def handle_memory_store(self, request: web.Request) -> web.Response:
        """POST /api/memory/store - Store memory."""
        try:
            data = await request.json()
            memory_type = data.get("type", "episodic")
            
            from memory.store import MemoryStore
            memory = MemoryStore()
            await memory.initialize()
            
            if memory_type == "episodic":
                memory_id = await memory.store_episodic(
                    event_type=data.get("event_type", "api_event"),
                    description=data.get("description", ""),
                    context=data.get("context", {}),
                    emotional_valence=data.get("emotional_valence", 0.0),
                    importance=data.get("importance", 0.5)
                )
            
            elif memory_type == "semantic":
                memory_id = await memory.store_semantic(
                    concept=data.get("concept", ""),
                    definition=data.get("definition", ""),
                    relations=data.get("relations", {}),
                    confidence=data.get("confidence", 0.8)
                )
            
            else:
                return web.json_response(
                    {"error": f"Unknown memory type: {memory_type}"},
                    status=400
                )
            
            await memory.close()
            
            return web.json_response({
                "memory_id": memory_id,
                "memory_type": memory_type,
                "timestamp": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            logger.error("memory_store_error", error=str(e))
            return web.json_response(
                {"error": str(e)},
                status=500
            )
