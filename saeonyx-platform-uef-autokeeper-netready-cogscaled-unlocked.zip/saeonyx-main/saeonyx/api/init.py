"""
SAEONYX API Layer
RESTful API server.

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

__version__ = "1.0"
__author__ = "Jake McDonough"
__email__ = "jake@saeonyx.com"

from .server import APIServer

__all__ = ["APIServer"]
