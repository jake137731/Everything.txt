"""
SAEONYX Quantum Simulation Layer
Local quantum computing simulation using Qiskit.

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

__version__ = "1.0"
__author__ = "Jake McDonough"
__email__ = "jake@saeonyx.com"

from .simulator import QuantumSimulator

__all__ = ["QuantumSimulator"]
