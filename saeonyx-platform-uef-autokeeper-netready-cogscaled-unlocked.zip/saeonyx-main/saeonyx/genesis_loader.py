#!/usr/bin/env python3
# =========================================================
# SAEONYX DNA-OS : GENESIS LOADER
# Author : Jake McDonough (SAEONYX Global Holdings LLC)
# Purpose: Stage-1 / Genesis activation of the SAEONYX platform
# =========================================================

import os
import sys
import json
import hashlib
import logging
from pathlib import Path
from datetime import datetime
from textwrap import indent


# ---------- CONFIGURATION CONSTANTS ----------

SAEONYX_ROOT = Path("/opt/saeonyx")
FOUNDATION_DIR = SAEONYX_ROOT / "foundation"
STATE_DIR = SAEONYX_ROOT / "state"
CONFIG_DIR = SAEONYX_ROOT / "config"

STAGE0_FILE = FOUNDATION_DIR / "STAGE0_PRIME_DIRECTIVE.md"
PRIME_JSON_FILE = SAEONYX_ROOT / "saeonyx_prime_directive.json"
GENESIS_PROMPT_FILE = SAEONYX_ROOT / "GENESIS_PROMPT.txt"
GENESIS_LOG_FILE = STATE_DIR / "GENESIS.log"

REQUIRE_ROOT = True  # set False if you want to run as non-root during dev


# ---------- UTILS ----------

def ensure_root():
    if not REQUIRE_ROOT:
        return
    if os.geteuid() != 0:
        print("❌ GENESIS LOADER must be run as root (sudo).", file=sys.stderr)
        sys.exit(1)


def ensure_dirs():
    for p in [SAEONYX_ROOT, FOUNDATION_DIR, STATE_DIR, CONFIG_DIR]:
        p.mkdir(parents=True, exist_ok=True)


def configure_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(GENESIS_LOG_FILE, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )
    logging.info("========================================================")
    logging.info("SAEONYX GENESIS LOADER STARTED")
    logging.info("Root: %s", SAEONYX_ROOT)


def sha256_of_path(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return "MISSING"
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def read_text_or_none(path: Path) -> str:
    if not path.exists():
        return ""
    try:
        return path.read_text(encoding="utf-8")
    except Exception as e:
        logging.error("Failed to read %s: %s", path, e)
        return ""


def load_json_or_none(path: Path):
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logging.error("Failed to parse JSON from %s: %s", path, e)
        return None


# ---------- GENESIS STEPS ----------

def log_foundation_summary():
    logging.info(">>> FOUNDATION CHECK")

    stage0_hash = sha256_of_path(STAGE0_FILE)
    prime_hash = sha256_of_path(PRIME_JSON_FILE)
    genesis_hash = sha256_of_path(GENESIS_PROMPT_FILE)

    logging.info("STAGE0_PRIME_DIRECTIVE: %s (%s)", STAGE0_FILE, stage0_hash)
    logging.info("PRIME_DIRECTIVE_JSON : %s (%s)", PRIME_JSON_FILE, prime_hash)
    logging.info("GENESIS_PROMPT       : %s (%s)", GENESIS_PROMPT_FILE, genesis_hash)

    if stage0_hash == "MISSING":
        logging.warning("!! Stage 0 Prime Directive is missing. Run Stage 0 installer before Genesis.")
    if prime_hash == "MISSING":
        logging.warning("!! saeonyx_prime_directive.json is missing. Platform will fall back to defaults.")
    if genesis_hash == "MISSING":
        logging.warning("!! GENESIS_PROMPT.txt is missing. Genesis will proceed with limited context.")


def load_prime_directive():
    logging.info(">>> LOADING PRIME DIRECTIVE")
    prime = load_json_or_none(PRIME_JSON_FILE)

    if prime is None:
        logging.warning("No JSON prime directive found at %s; continuing without structured directive.", PRIME_JSON_FILE)
        return {}

    # Minimal sanity checks
    identity = prime.get("identity", {})
    name = identity.get("name", "UNKNOWN")
    desc = identity.get("description", "")

    logging.info("PRIME IDENTITY: %s", name)
    if desc:
        logging.info("PRIME DESCRIPTION:\n%s", indent(desc, "    "))

    return prime


def load_stage0_text():
    logging.info(">>> LOADING STAGE 0 CHARTER")
    text = read_text_or_none(STAGE0_FILE)
    if not text:
        logging.warning("Stage 0 charter text is empty or missing.")
        return ""
    preview = "\n".join(text.splitlines()[:20])  # first 20 lines
    logging.info("STAGE 0 PREVIEW:\n%s", indent(preview, "    "))
    return text


def load_genesis_prompt():
    logging.info(">>> LOADING GENESIS PROMPT")
    prompt = read_text_or_none(GENESIS_PROMPT_FILE)
    if not prompt:
        logging.warning("GENESIS_PROMPT.txt not found; skipping prompt-based initialization.")
        return ""
    preview = "\n".join(prompt.splitlines()[:15])
    logging.info("GENESIS PROMPT PREVIEW:\n%s", indent(preview, "    "))
    return prompt


def write_boot_record(prime: dict, stage0_text: str, genesis_prompt: str):
    logging.info(">>> WRITING GENESIS BOOT RECORD")

    record = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "root": str(SAEONYX_ROOT),
        "stage0_present": bool(stage0_text),
        "genesis_prompt_present": bool(genesis_prompt),
        "prime_identity": prime.get("identity", {}),
        "ethics_summary": prime.get("ethics", {}),
        "behavioral_mandate": prime.get("behavioral_mandate", {}),
        "meta_guidelines": prime.get("meta_guidelines", {}),
        "hashes": {
            "stage0": sha256_of_path(STAGE0_FILE),
            "prime_json": sha256_of_path(PRIME_JSON_FILE),
            "genesis_prompt": sha256_of_path(GENESIS_PROMPT_FILE),
        },
    }

    # Append a JSON block to GENESIS.log for machine reading
    try:
        with GENESIS_LOG_FILE.open("a", encoding="utf-8") as f:
            f.write("\n\n# GENESIS BOOT RECORD\n")
            f.write(json.dumps(record, indent=2))
            f.write("\n")
        logging.info("Boot record appended to %s", GENESIS_LOG_FILE)
    except Exception as e:
        logging.error("Failed to append boot record: %s", e)


def attempt_core_bootstrap(prime: dict):
    """
    Try to import the SAEONYX core package and delegate further startup.
    This allows the loader to be used even before the full codebase exists.
    """
    logging.info(">>> ATTEMPTING CORE BOOTSTRAP")

    try:
        import importlib

        # Try several likely module paths; adapt as your core evolves.
        candidates = [
            "saeonyx",
            "saeonyx.core",
            "saeonyx.runtime",
        ]

        module = None
        for name in candidates:
            try:
                module = importlib.import_module(name)
                logging.info("Imported core module: %s", name)
                break
            except ModuleNotFoundError:
                continue

        if module is None:
            logging.warning("No SAEONYX core module found; Genesis will stop at foundation load.")
            return

        # Look for a bootstrap function.
        bootstrap = getattr(module, "bootstrap", None)
        if bootstrap is None or not callable(bootstrap):
            logging.warning(
                "Core module %s does not expose a callable 'bootstrap(prime_directive: dict)'. "
                "Skipping runtime initialization.", module.__name__
            )
            return

        logging.info("Calling core bootstrap with Prime Directive context...")
        bootstrap(prime_directive=prime)

        logging.info("SAEONYX core bootstrap completed.")
    except Exception as e:
        logging.error("Fatal error during core bootstrap: %s", e, exc_info=True)


def main():
    ensure_root()
    ensure_dirs()
    configure_logging()

    log_foundation_summary()

    stage0_text = load_stage0_text()
    prime = load_prime_directive()
    genesis_prompt = load_genesis_prompt()

    write_boot_record(prime, stage0_text, genesis_prompt)
    attempt_core_bootstrap(prime)

    logging.info("SAEONYX GENESIS LOADER FINISHED")
    logging.info("========================================================")


if __name__ == "__main__":
    main()