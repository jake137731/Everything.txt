"""
digital_twin.py
SAEONYX Digital Twin Engine
Create, synchronize, and simulate digital twins of physical systems

Author: Jake McDonough
Contact: jake@saeonyx.com
Created: November 18, 2025

CAPABILITIES:
- System modeling and twin creation
- Real-time data synchronization
- Predictive simulation
- Anomaly detection
- Optimization recommendations
- IoT integration
- Industrial systems (manufacturing, supply chain)
- Medical systems (patient health monitoring)
- Infrastructure (buildings, cities, energy grids)

APPLICATIONS:
- Predictive maintenance
- Process optimization
- Health monitoring
- Smart cities
- Supply chain logistics
"""

import json
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass, field
import structlog
import asyncio

logger = structlog.get_logger()


@dataclass
class TwinState:
    """Represents current state of a digital twin."""
    twin_id: str
    timestamp: datetime
    parameters: Dict[str, Any]
    metrics: Dict[str, float]
    health_score: float = 1.0
    anomalies: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "twin_id": self.twin_id,
            "timestamp": self.timestamp.isoformat(),
            "parameters": self.parameters,
            "metrics": self.metrics,
            "health_score": self.health_score,
            "anomalies": self.anomalies
        }


@dataclass
class TwinPrediction:
    """Prediction from digital twin simulation."""
    twin_id: str
    prediction_horizon: timedelta
    predicted_state: TwinState
    confidence: float
    recommendations: List[str]
    timestamp: datetime


class DigitalTwin:
    """
    Digital Twin base class.
    
    A digital twin is a virtual representation of a physical system
    that:
    1. Mirrors current state (synchronization)
    2. Predicts future behavior (simulation)
    3. Identifies anomalies (monitoring)
    4. Suggests optimizations (recommendations)
    """
    
    def __init__(
        self,
        twin_id: str,
        twin_type: str,
        description: str,
        initial_state: Dict[str, Any] = None
    ):
        self.twin_id = twin_id
        self.twin_type = twin_type
        self.description = description
        self.created_at = datetime.utcnow()
        
        # State management
        self.current_state: Optional[TwinState] = None
        self.state_history: List[TwinState] = []
        
        # Simulation parameters
        self.physics_model: Optional[Callable] = None
        self.degradation_model: Optional[Callable] = None
        
        # Monitoring
        self.alert_thresholds: Dict[str, Tuple[float, float]] = {}
        self.anomaly_patterns: List[Dict[str, Any]] = []
        
        if initial_state:
            self.update_state(initial_state)
        
        logger.info("digital_twin_created", twin_id=twin_id, type=twin_type)
    
    def update_state(self, new_data: Dict[str, Any]):
        """Update twin state with new sensor/system data."""
        timestamp = new_data.get("timestamp", datetime.utcnow())
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp)
        
        # Extract parameters and metrics
        parameters = new_data.get("parameters", {})
        metrics = new_data.get("metrics", {})
        
        # Calculate health score
        health_score = self._calculate_health_score(metrics)
        
        # Detect anomalies
        anomalies = self._detect_anomalies(metrics)
        
        # Create new state
        new_state = TwinState(
            twin_id=self.twin_id,
            timestamp=timestamp,
            parameters=parameters,
            metrics=metrics,
            health_score=health_score,
            anomalies=anomalies
        )
        
        # Update history
        if self.current_state:
            self.state_history.append(self.current_state)
        self.current_state = new_state
        
        # Limit history size
        if len(self.state_history) > 1000:
            self.state_history = self.state_history[-1000:]
        
        logger.info(
            "twin_state_updated",
            twin_id=self.twin_id,
            health=health_score,
            anomalies=len(anomalies)
        )
    
    def _calculate_health_score(self, metrics: Dict[str, float]) -> float:
        """Calculate overall health score (0-1)."""
        if not metrics:
            return 1.0
        
        scores = []
        for metric_name, value in metrics.items():
            if metric_name in self.alert_thresholds:
                min_val, max_val = self.alert_thresholds[metric_name]
                
                # Normalize to 0-1 range
                if value < min_val:
                    score = max(0.0, 1.0 - (min_val - value) / min_val)
                elif value > max_val:
                    score = max(0.0, 1.0 - (value - max_val) / max_val)
                else:
                    score = 1.0
                
                scores.append(score)
        
        return sum(scores) / len(scores) if scores else 1.0
    
    def _detect_anomalies(self, metrics: Dict[str, float]) -> List[str]:
        """Detect anomalies in current metrics."""
        anomalies = []
        
        for metric_name, value in metrics.items():
            if metric_name in self.alert_thresholds:
                min_val, max_val = self.alert_thresholds[metric_name]
                
                if value < min_val:
                    anomalies.append(f"{metric_name} below threshold: {value} < {min_val}")
                elif value > max_val:
                    anomalies.append(f"{metric_name} above threshold: {value} > {max_val}")
        
        return anomalies
    
    async def predict_future_state(
        self,
        hours_ahead: int = 24
    ) -> TwinPrediction:
        """
        Predict future state using physics and degradation models.
        """
        if not self.current_state:
            raise ValueError("No current state available for prediction")
        
        logger.info("twin_prediction_starting", twin_id=self.twin_id, hours=hours_ahead)
        
        # Simple linear extrapolation (override with physics models)
        predicted_metrics = self.current_state.metrics.copy()
        
        # Apply degradation model if available
        if self.degradation_model:
            predicted_metrics = self.degradation_model(
                predicted_metrics,
                hours_ahead
            )
        else:
            # Simple degradation assumption
            for metric in predicted_metrics:
                predicted_metrics[metric] *= 0.99  # 1% degradation
        
        # Create predicted state
        predicted_state = TwinState(
            twin_id=self.twin_id,
            timestamp=self.current_state.timestamp + timedelta(hours=hours_ahead),
            parameters=self.current_state.parameters.copy(),
            metrics=predicted_metrics,
            health_score=self._calculate_health_score(predicted_metrics),
            anomalies=self._detect_anomalies(predicted_metrics)
        )
        
        # Generate recommendations
        recommendations = self._generate_recommendations(predicted_state)
        
        # Calculate confidence based on data quality
        confidence = min(1.0, len(self.state_history) / 100)
        
        prediction = TwinPrediction(
            twin_id=self.twin_id,
            prediction_horizon=timedelta(hours=hours_ahead),
            predicted_state=predicted_state,
            confidence=confidence,
            recommendations=recommendations,
            timestamp=datetime.utcnow()
        )
        
        logger.info("twin_prediction_complete", health=predicted_state.health_score)
        return prediction
    
    def _generate_recommendations(self, predicted_state: TwinState) -> List[str]:
        """Generate optimization recommendations."""
        recommendations = []
        
        if predicted_state.health_score < 0.7:
            recommendations.append("Health score declining - schedule maintenance")
        
        if predicted_state.anomalies:
            recommendations.append(f"Anomalies detected: {len(predicted_state.anomalies)} - investigate immediately")
        
        for metric, value in predicted_state.metrics.items():
            if metric in self.alert_thresholds:
                min_val, max_val = self.alert_thresholds[metric]
                
                # Predictive warnings
                range_pct = (max_val - min_val) * 0.2
                if value < min_val + range_pct:
                    recommendations.append(f"Warning: {metric} approaching lower limit")
                elif value > max_val - range_pct:
                    recommendations.append(f"Warning: {metric} approaching upper limit")
        
        return recommendations
    
    def set_alert_threshold(self, metric_name: str, min_val: float, max_val: float):
        """Set alert thresholds for a metric."""
        self.alert_thresholds[metric_name] = (min_val, max_val)
        logger.info("threshold_set", metric=metric_name, min=min_val, max=max_val)
    
    def get_state_history(self, hours: int = 24) -> List[TwinState]:
        """Get state history for last N hours."""
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        return [s for s in self.state_history if s.timestamp >= cutoff]


class IndustrialTwin(DigitalTwin):
    """
    Digital twin for industrial equipment (manufacturing, machines).
    """
    
    def __init__(self, twin_id: str, equipment_type: str, initial_state: Dict = None):
        super().__init__(
            twin_id=twin_id,
            twin_type="industrial",
            description=f"Industrial equipment twin: {equipment_type}",
            initial_state=initial_state
        )
        
        # Default thresholds for common industrial metrics
        self.set_alert_threshold("temperature", 0, 150)  # Celsius
        self.set_alert_threshold("vibration", 0, 10)     # mm/s
        self.set_alert_threshold("pressure", 0, 100)     # PSI
        self.set_alert_threshold("rpm", 0, 3000)         # RPM
        self.set_alert_threshold("power_consumption", 0, 1000)  # kW
    
    async def calculate_remaining_useful_life(self) -> Dict[str, Any]:
        """Calculate predicted remaining useful life (RUL)."""
        if len(self.state_history) < 10:
            return {
                "rul_hours": None,
                "confidence": 0.0,
                "message": "Insufficient data for RUL prediction"
            }
        
        # Simple degradation rate calculation
        recent_states = self.state_history[-10:]
        health_scores = [s.health_score for s in recent_states]
        
        # Calculate degradation rate
        if len(health_scores) > 1:
            degradation_rate = (health_scores[0] - health_scores[-1]) / len(health_scores)
            
            if degradation_rate > 0:
                # Predict when health score reaches critical threshold (0.3)
                current_health = self.current_state.health_score
                rul_hours = (current_health - 0.3) / degradation_rate
                
                return {
                    "rul_hours": max(0, rul_hours),
                    "confidence": min(1.0, len(self.state_history) / 100),
                    "degradation_rate": degradation_rate,
                    "current_health": current_health
                }
        
        return {
            "rul_hours": None,
            "confidence": 0.5,
            "message": "Equipment health stable"
        }


class MedicalTwin(DigitalTwin):
    """
    Digital twin for patient health monitoring.
    
    HIPAA compliant - no PHI in logs.
    """
    
    def __init__(self, twin_id: str, patient_info: Dict = None):
        # Anonymized twin ID only
        super().__init__(
            twin_id=twin_id,
            twin_type="medical",
            description="Patient health monitoring twin",
            initial_state=patient_info
        )
        
        # Default vital sign thresholds
        self.set_alert_threshold("heart_rate", 60, 100)      # bpm
        self.set_alert_threshold("blood_pressure_sys", 90, 140)  # mmHg
        self.set_alert_threshold("blood_pressure_dia", 60, 90)   # mmHg
        self.set_alert_threshold("temperature", 36.1, 37.8)  # Celsius
        self.set_alert_threshold("spo2", 95, 100)            # %
        self.set_alert_threshold("respiratory_rate", 12, 20) # breaths/min
    
    async def assess_patient_risk(self) -> Dict[str, Any]:
        """Assess patient risk level based on current state."""
        if not self.current_state:
            return {"risk_level": "unknown", "factors": []}
        
        risk_factors = []
        risk_score = 0.0
        
        # Check vital signs
        metrics = self.current_state.metrics
        
        for metric, value in metrics.items():
            if metric in self.alert_thresholds:
                min_val, max_val = self.alert_thresholds[metric]
                
                if value < min_val or value > max_val:
                    risk_factors.append(f"{metric} out of range: {value}")
                    risk_score += 0.2
        
        # Check for anomalies
        if self.current_state.anomalies:
            risk_score += len(self.current_state.anomalies) * 0.1
            risk_factors.extend(self.current_state.anomalies)
        
        # Classify risk level
        if risk_score >= 0.7:
            risk_level = "high"
            action = "immediate_intervention_required"
        elif risk_score >= 0.4:
            risk_level = "medium"
            action = "close_monitoring_recommended"
        elif risk_score >= 0.2:
            risk_level = "low"
            action = "routine_monitoring"
        else:
            risk_level = "normal"
            action = "continue_standard_care"
        
        return {
            "risk_level": risk_level,
            "risk_score": min(1.0, risk_score),
            "risk_factors": risk_factors,
            "recommended_action": action,
            "timestamp": datetime.utcnow().isoformat()
        }


class TwinManager:
    """
    Manages multiple digital twins.
    
    Provides:
    - Twin lifecycle management
    - Data aggregation across twins
    - Fleet-level analytics
    - Optimization across systems
    """
    
    def __init__(self):
        self.twins: Dict[str, DigitalTwin] = {}
        logger.info("twin_manager_initialized")
    
    def create_twin(
        self,
        twin_id: str,
        twin_class: type,
        **kwargs
    ) -> DigitalTwin:
        """Create and register a new digital twin."""
        twin = twin_class(twin_id=twin_id, **kwargs)
        self.twins[twin_id] = twin
        logger.info("twin_registered", twin_id=twin_id, type=twin.twin_type)
        return twin
    
    def get_twin(self, twin_id: str) -> Optional[DigitalTwin]:
        """Retrieve a twin by ID."""
        return self.twins.get(twin_id)
    
    def remove_twin(self, twin_id: str):
        """Decommission a twin."""
        if twin_id in self.twins:
            del self.twins[twin_id]
            logger.info("twin_removed", twin_id=twin_id)
    
    async def update_all_twins(self, data_batch: Dict[str, Dict[str, Any]]):
        """Update multiple twins with new data."""
        for twin_id, data in data_batch.items():
            if twin_id in self.twins:
                self.twins[twin_id].update_state(data)
    
    async def get_fleet_health(self) -> Dict[str, Any]:
        """Get aggregate health metrics across all twins."""
        if not self.twins:
            return {"status": "no_twins", "count": 0}
        
        health_scores = []
        anomaly_count = 0
        critical_twins = []
        
        for twin_id, twin in self.twins.items():
            if twin.current_state:
                health_scores.append(twin.current_state.health_score)
                anomaly_count += len(twin.current_state.anomalies)
                
                if twin.current_state.health_score < 0.5:
                    critical_twins.append(twin_id)
        
        avg_health = sum(health_scores) / len(health_scores) if health_scores else 0.0
        
        return {
            "total_twins": len(self.twins),
            "average_health": avg_health,
            "total_anomalies": anomaly_count,
            "critical_twins": critical_twins,
            "healthy_twins": len([h for h in health_scores if h >= 0.8]),
            "timestamp": datetime.utcnow().isoformat()
        }
    
    async def optimize_fleet(self) -> List[Dict[str, Any]]:
        """Generate fleet-level optimization recommendations."""
        recommendations = []
        
        # Get fleet health
        fleet_health = await self.get_fleet_health()
        
        # Prioritize critical twins
        if fleet_health["critical_twins"]:
            recommendations.append({
                "priority": "critical",
                "action": "immediate_maintenance",
                "twins": fleet_health["critical_twins"],
                "message": f"{len(fleet_health['critical_twins'])} twin(s) require immediate attention"
            })
        
        # Overall fleet optimization
        if fleet_health["average_health"] < 0.7:
            recommendations.append({
                "priority": "high",
                "action": "fleet_assessment",
                "message": "Average fleet health below 70% - comprehensive review recommended"
            })
        
        return recommendations
    
    def export_twins_data(self) -> Dict[str, Any]:
        """Export all twin states for analysis."""
        export = {
            "timestamp": datetime.utcnow().isoformat(),
            "twin_count": len(self.twins),
            "twins": {}
        }
        
        for twin_id, twin in self.twins.items():
            if twin.current_state:
                export["twins"][twin_id] = twin.current_state.to_dict()
        
        return export
