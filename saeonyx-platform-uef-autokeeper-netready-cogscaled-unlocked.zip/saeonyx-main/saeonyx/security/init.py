"""
SAEONYX Security Layer
Zero-trust security enforcement.

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

__version__ = "1.0"
__author__ = "Jake McDonough"
__email__ = "jake@saeonyx.com"

from .zero_trust import ZeroTrustManager

__all__ = ["ZeroTrustManager"]
