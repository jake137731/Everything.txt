"""
SAEONYX Memory Store
Local distributed memory using SQLite (no external database).

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

import aiosqlite
import json
import hashlib
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import structlog

logger = structlog.get_logger()


class MemoryStore:
    """
    Distributed memory storage system.
    
    Uses local SQLite for zero external dependencies.
    Implements:
    - Episodic memory (events, experiences)
    - Semantic memory (facts, knowledge)
    - Procedural memory (skills, patterns)
    - Working memory (current context)
    """
    
    DB_PATH = Path("/opt/saeonyx/data/memory.db")
    
    def __init__(self):
        self.db_path = self.DB_PATH
        self.db = None
        self.active = False
    
    async def initialize(self):
        """Initialize memory store and create tables."""
        logger.info("memory_store_initializing")
        
        # Ensure directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Connect to database
        self.db = await aiosqlite.connect(str(self.db_path))
        
        # Create tables
        await self._create_tables()
        
        self.active = True
        logger.info("memory_store_initialized", db_path=str(self.db_path))
    
    async def _create_tables(self):
        """Create memory tables."""
        # Episodic memory (events, experiences)
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS episodic_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_id TEXT UNIQUE NOT NULL,
                timestamp TEXT NOT NULL,
                event_type TEXT NOT NULL,
                description TEXT,
                context TEXT,
                emotional_valence REAL,
                importance REAL,
                created_at TEXT NOT NULL
            )
        """)
        
        # Semantic memory (facts, knowledge)
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS semantic_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_id TEXT UNIQUE NOT NULL,
                concept TEXT NOT NULL,
                definition TEXT,
                relations TEXT,
                confidence REAL,
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
        """)
        
        # Procedural memory (skills, patterns)
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS procedural_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_id TEXT UNIQUE NOT NULL,
                skill_name TEXT NOT NULL,
                pattern TEXT,
                success_rate REAL,
                usage_count INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                last_used TEXT
            )
        """)
        
        # Working memory (current context)
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS working_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_id TEXT UNIQUE NOT NULL,
                context_key TEXT NOT NULL,
                context_value TEXT,
                ttl INTEGER,
                created_at TEXT NOT NULL
            )
        """)
        
        await self.db.commit()
    
    async def store_episodic(
        self,
        event_type: str,
        description: str,
        context: Dict[str, Any],
        emotional_valence: float = 0.0,
        importance: float = 0.5
    ) -> str:
        """
        Store episodic memory (event, experience).
        
        Args:
            event_type: Type of event (e.g., "task_execution", "interaction")
            description: Human-readable description
            context: Dictionary of context data
            emotional_valence: -1.0 (negative) to 1.0 (positive)
            importance: 0.0 (trivial) to 1.0 (critical)
        """
        memory_id = self._generate_id(event_type, description)
        timestamp = datetime.utcnow().isoformat()
        context_json = json.dumps(context)
        
        await self.db.execute("""
            INSERT INTO episodic_memory 
            (memory_id, timestamp, event_type, description, context, 
             emotional_valence, importance, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            memory_id, timestamp, event_type, description, context_json,
            emotional_valence, importance, timestamp
        ))
        
        await self.db.commit()
        
        logger.debug("episodic_memory_stored", memory_id=memory_id, event_type=event_type)
        return memory_id
    
    async def store_semantic(
        self,
        concept: str,
        definition: str,
        relations: Dict[str, Any] = None,
        confidence: float = 0.8
    ) -> str:
        """
        Store semantic memory (fact, knowledge).
        
        Args:
            concept: The concept/fact name
            definition: Definition or description
            relations: Related concepts/facts
            confidence: Confidence in this knowledge (0-1)
        """
        memory_id = self._generate_id("semantic", concept)
        timestamp = datetime.utcnow().isoformat()
        relations_json = json.dumps(relations or {})
        
        # Check if exists, update if so
        cursor = await self.db.execute(
            "SELECT id FROM semantic_memory WHERE concept = ?",
            (concept,)
        )
        existing = await cursor.fetchone()
        
        if existing:
            await self.db.execute("""
                UPDATE semantic_memory
                SET definition = ?, relations = ?, confidence = ?, updated_at = ?
                WHERE concept = ?
            """, (definition, relations_json, confidence, timestamp, concept))
        else:
            await self.db.execute("""
                INSERT INTO semantic_memory
                (memory_id, concept, definition, relations, confidence, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (memory_id, concept, definition, relations_json, confidence, timestamp))
        
        await self.db.commit()
        
        logger.debug("semantic_memory_stored", memory_id=memory_id, concept=concept)
        return memory_id
    
    async def store_procedural(
        self,
        skill_name: str,
        pattern: Dict[str, Any],
        success_rate: float = 0.0
    ) -> str:
        """
        Store procedural memory (skill, pattern).
        
        Args:
            skill_name: Name of the skill
            pattern: Pattern or procedure data
            success_rate: Historical success rate (0-1)
        """
        memory_id = self._generate_id("procedural", skill_name)
        timestamp = datetime.utcnow().isoformat()
        pattern_json = json.dumps(pattern)
        
        await self.db.execute("""
            INSERT INTO procedural_memory
            (memory_id, skill_name, pattern, success_rate, usage_count, 
             created_at, last_used)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (memory_id, skill_name, pattern_json, success_rate, 0, timestamp, timestamp))
        
        await self.db.commit()
        
        logger.debug("procedural_memory_stored", memory_id=memory_id, skill_name=skill_name)
        return memory_id
    
    async def store_working(
        self,
        context_key: str,
        context_value: Any,
        ttl: int = 3600
    ) -> str:
        """
        Store working memory (current context).
        
        Args:
            context_key: Key for the context
            context_value: Value (any JSON-serializable data)
            ttl: Time-to-live in seconds
        """
        memory_id = self._generate_id("working", context_key)
        timestamp = datetime.utcnow().isoformat()
        value_json = json.dumps(context_value)
        
        # Upsert working memory
        await self.db.execute("""
            INSERT OR REPLACE INTO working_memory
            (memory_id, context_key, context_value, ttl, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (memory_id, context_key, value_json, ttl, timestamp))
        
        await self.db.commit()
        
        logger.debug("working_memory_stored", memory_id=memory_id, context_key=context_key)
        return memory_id
    
    async def retrieve_episodic(
        self,
        event_type: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Retrieve episodic memories."""
        if event_type:
            cursor = await self.db.execute("""
                SELECT * FROM episodic_memory
                WHERE event_type = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """, (event_type, limit))
        else:
            cursor = await self.db.execute("""
                SELECT * FROM episodic_memory
                ORDER BY timestamp DESC
                LIMIT ?
            """, (limit,))
        
        rows = await cursor.fetchall()
        
        memories = []
        for row in rows:
            memories.append({
                "memory_id": row[1],
                "timestamp": row[2],
                "event_type": row[3],
                "description": row[4],
                "context": json.loads(row[5]),
                "emotional_valence": row[6],
                "importance": row[7]
            })
        
        return memories
    
    async def retrieve_semantic(self, concept: str) -> Optional[Dict[str, Any]]:
        """Retrieve semantic memory by concept."""
        cursor = await self.db.execute("""
            SELECT * FROM semantic_memory WHERE concept = ?
        """, (concept,))
        
        row = await cursor.fetchone()
        if not row:
            return None
        
        return {
            "memory_id": row[1],
            "concept": row[2],
            "definition": row[3],
            "relations": json.loads(row[4]),
            "confidence": row[5]
        }
    
    async def retrieve_working(self, context_key: str) -> Optional[Any]:
        """Retrieve working memory by key."""
        cursor = await self.db.execute("""
            SELECT context_value FROM working_memory WHERE context_key = ?
        """, (context_key,))
        
        row = await cursor.fetchone()
        if not row:
            return None
        
        return json.loads(row[0])
    
    async def search_memories(
        self,
        query: str,
        memory_type: str = "episodic",
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Search memories by query string.
        
        Simple keyword search (can be enhanced with vector embeddings).
        """
        if memory_type == "episodic":
            cursor = await self.db.execute("""
                SELECT * FROM episodic_memory
                WHERE description LIKE ?
                ORDER BY importance DESC, timestamp DESC
                LIMIT ?
            """, (f"%{query}%", limit))
        elif memory_type == "semantic":
            cursor = await self.db.execute("""
                SELECT * FROM semantic_memory
                WHERE concept LIKE ? OR definition LIKE ?
                ORDER BY confidence DESC
                LIMIT ?
            """, (f"%{query}%", f"%{query}%", limit))
        else:
            return []
        
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]
    
    async def get_statistics(self) -> Dict[str, Any]:
        """Get memory store statistics."""
        stats = {}
        
        for table in ["episodic_memory", "semantic_memory", "procedural_memory", "working_memory"]:
            cursor = await self.db.execute(f"SELECT COUNT(*) FROM {table}")
            count = await cursor.fetchone()
            stats[table] = count[0]
        
        return stats
    
    def _generate_id(self, prefix: str, content: str) -> str:
        """Generate unique memory ID."""
        hash_input = f"{prefix}:{content}:{datetime.utcnow().isoformat()}"
        return f"{prefix}_{hashlib.sha256(hash_input.encode()).hexdigest()[:16]}"
    
    async def close(self):
        """Close database connection."""
        if self.db:
            await self.db.close()
            logger.info("memory_store_closed")
