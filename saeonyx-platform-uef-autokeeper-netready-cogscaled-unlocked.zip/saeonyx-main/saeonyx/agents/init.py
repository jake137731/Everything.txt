"""
SAEONYX Agent Orchestration System
12-agent swarm with IRIS recursive enhancement.

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

__version__ = "1.0"
__author__ = "Jake McDonough"
__email__ = "jake@saeonyx.com"

from .orchestrator import AgentOrchestrator
from .base import BaseAgent
from .iris import IRISController

__all__ = [
    "AgentOrchestrator",
    "BaseAgent",
    "IRISController",
]
