"""
agents/base.py
SAEONYX Base Agent Infrastructure
Enterprise-grade primitives, data models, and base classes.
"""

import asyncio
import uuid
import traceback
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime
from pydantic import BaseModel, Field
import structlog

logger = structlog.get_logger()

# --- Strict Data Models (Pydantic) ---

class AgentCapability(BaseModel):
    name: str
    description: str
    confidence: float = Field(..., ge=0.0, le=1.0)

class AgentTask(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    description: str
    payload: Dict[str, Any] = {} # The actual input data
    context: Dict[str, Any] = {} # Meta-data (orchestration flags, etc.)
    priority: int = Field(default=5, ge=1, le=10)
    required_capabilities: List[str] = []

class AgentResult(BaseModel):
    task_id: str
    agent_id: str
    success: bool
    output: Any # Renamed from 'data' to 'output' to match Orchestrator expectations
    meta: Dict[str, Any] = {}
    confidence: float = Field(..., ge=0.0, le=1.0)
    execution_time_ms: float
    timestamp: str = Field(default_factory=lambda: datetime.utcnow().isoformat())

# --- Base Agent with Circuit Breaker ---

class BaseAgent(ABC):
    """
    Abstract base class for all SAEONYX agents.
    Includes built-in retry logic, circuit breaking, and strict typing.
    """
    
    def __init__(self, agent_id: str, name: str, description: str):
        self.agent_id = agent_id
        self.name = name
        self.description = description
        self.logger = logger.bind(agent_id=agent_id)
        self.active = True
        self._circuit_open = False
        self._failure_count = 0
    
    async def initialize(self):
        """Lifecycle hook for startup."""
        self.logger.info("agent_initialized", name=self.name)
        self.active = True

    async def shutdown(self):
        """Lifecycle hook for shutdown."""
        self.active = False
        self.logger.info("agent_shutdown", name=self.name)

    @abstractmethod
    async def execute_logic(self, payload: Dict[str, Any]) -> Any:
        """
        Core logic implementation. 
        Must be implemented by the specialized agent.
        """
        pass
    
    @abstractmethod
    async def get_capabilities(self) -> List[AgentCapability]:
        pass
    
    async def validate_task(self, task: AgentTask) -> bool:
        """Validation logic."""
        caps = await self.get_capabilities()
        my_cap_names = {c.name for c in caps}
        
        # Check requirements
        for req in task.required_capabilities:
            if req not in my_cap_names:
                return False
        return True
    
    async def execute_safe(self, task: AgentTask) -> AgentResult:
        """
        Wrapper for execute_logic. Handles errors, retries, and logging.
        """
        if self._circuit_open:
            return self._error_result(task, "Circuit Breaker OPEN")

        start = datetime.utcnow()
        
        try:
            if not await self.validate_task(task):
                raise ValueError(f"Task validation failed for {self.agent_id}: Missing capabilities")

            # Retry loop
            result_data = await self._retry_logic(task.payload)
            
            duration = (datetime.utcnow() - start).total_seconds() * 1000
            self._failure_count = 0 # Reset failures on success
            
            return AgentResult(
                task_id=task.task_id,
                agent_id=self.agent_id,
                success=True,
                output=result_data,
                confidence=0.95, 
                execution_time_ms=duration
            )

        except Exception as e:
            self._failure_count += 1
            if self._failure_count > 5:
                self._circuit_open = True
                self.logger.critical("circuit_breaker_tripped")
            
            duration = (datetime.utcnow() - start).total_seconds() * 1000
            self.logger.error("execution_failed", error=str(e), traceback=traceback.format_exc())
            return self._error_result(task, str(e), duration)

    async def _retry_logic(self, payload: Dict[str, Any], retries=2):
        for i in range(retries + 1):
            try:
                return await self.execute_logic(payload)
            except Exception:
                if i == retries: raise
                await asyncio.sleep(0.1 * (2**i)) # Exponential backoff

    def _error_result(self, task: AgentTask, error: str, duration: float = 0.0) -> AgentResult:
        return AgentResult(
            task_id=task.task_id,
            agent_id=self.agent_id,
            success=False,
            output={"error": error},
            confidence=0.0,
            execution_time_ms=duration
        )

    async def get_status(self) -> Dict[str, Any]:
        return {"id": self.agent_id, "active": self.active, "circuit_open": self._circuit_open}
