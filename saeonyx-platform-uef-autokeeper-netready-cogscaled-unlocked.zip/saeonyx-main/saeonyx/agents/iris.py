"""
SAEONYX IRIS Controller
Iterative Recursive Improvement System for agent coordination.

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

from typing import Dict, Any, List
import structlog
from .base import AgentTask, AgentResult

logger = structlog.get_logger()


class IRISController:
    """
    IRIS: Iterative Recursive Improvement System
    
    Coordinates recursive enhancement of agent outputs through:
    1. Task decomposition
    2. Parallel execution
    3. Result synthesis
    4. Iterative refinement
    """
    
    def __init__(self, agents: Dict[str, Any]):
        self.agents = agents
        self.active = False
        self.enhancement_cycles = 0
        self.max_cycles = 3  # Prevent infinite recursion
    
    async def initialize(self):
        """Initialize IRIS controller."""
        logger.info("iris_initializing")
        self.active = True
        logger.info("iris_initialized")
    
    async def shutdown(self):
        """Shutdown IRIS controller."""
        logger.info("iris_shutting_down")
        self.active = False
        logger.info("iris_shutdown_complete")
    
    async def assign_task(self, task: AgentTask) -> Dict[str, Any]:
        """
        Assign task to optimal agents using IRIS logic.
        
        Returns assignment dict with agent IDs and execution plan.
        """
        # Analyze task requirements
        requirements = await self._analyze_requirements(task)
        
        # Match agents to requirements
        matched_agents = await self._match_agents(requirements)
        
        # Generate execution plan
        plan = await self._generate_plan(task, matched_agents)
        
        return {
            "agents": matched_agents,
            "plan": plan,
            "requirements": requirements
        }
    
    async def _analyze_requirements(self, task: AgentTask) -> Dict[str, Any]:
        """Analyze task to determine requirements."""
        description = task.description.lower()
        
        requirements = {
            "capabilities": [],
            "complexity": "medium",
            "priority": task.priority
        }
        
        # Keyword-based requirement detection
        if any(word in description for word in ["analyze", "understand", "parse"]):
            requirements["capabilities"].append("analyzer")
        
        if any(word in description for word in ["optimize", "improve", "enhance"]):
            requirements["capabilities"].append("optimizer")
        
        if any(word in description for word in ["consciousness", "phi", "awareness"]):
            requirements["capabilities"].append("consciousness")
        
        if any(word in description for word in ["moral", "ethics", "soul"]):
            requirements["capabilities"].append("soul_vector")
        
        if any(word in description for word in ["quantum", "superposition", "collapse"]):
            requirements["capabilities"].append("quantum")
        
        if any(word in description for word in ["evolve", "mutate", "genetic"]):
            requirements["capabilities"].append("evolution")
        
        if any(word in description for word in ["security", "secure", "protect"]):
            requirements["capabilities"].append("security")
        
        if any(word in description for word in ["memory", "remember", "recall"]):
            requirements["capabilities"].append("memory")
        
        # Default to analyzer if no specific match
        if not requirements["capabilities"]:
            requirements["capabilities"].append("analyzer")
        
        return requirements
    
    async def _match_agents(self, requirements: Dict[str, Any]) -> List[str]:
        """Match agents to requirements."""
        matched = []
        
        capability_to_agent = {
            "analyzer": "analyzer",
            "optimizer": "optimizer",
            "consciousness": "consciousness",
            "soul_vector": "soul_vector",
            "quantum": "quantum",
            "evolution": "evolution",
            "security": "security",
            "memory": "memory",
            "api": "api",
            "web": "web",
            "deployment": "deployment",
            "monitor": "monitor"
        }
        
        for capability in requirements["capabilities"]:
            agent_id = capability_to_agent.get(capability)
            if agent_id and agent_id in self.agents:
                matched.append(agent_id)
        
        return matched
    
    async def _generate_plan(
        self,
        task: AgentTask,
        agents: List[str]
    ) -> Dict[str, Any]:
        """Generate execution plan for agents."""
        return {
            "execution_mode": "parallel" if len(agents) > 1 else "single",
            "agents": agents,
            "steps": [
                {
                    "step": 1,
                    "action": "execute",
                    "agents": agents
                },
                {
                    "step": 2,
                    "action": "synthesize",
                    "agents": ["analyzer"]
                }
            ]
        }
    
    async def enhance_results(
        self,
        results: List[AgentResult]
    ) -> List[AgentResult]:
        """
        Recursively enhance agent results.
        
        IRIS iteratively improves outputs through:
        1. Quality assessment
        2. Refinement suggestions
        3. Re-execution
        4. Convergence check
        """
        if self.enhancement_cycles >= self.max_cycles:
            logger.warning("max_enhancement_cycles_reached")
            return results
        
        self.enhancement_cycles += 1
        
        # Assess quality
        quality_scores = [self._assess_quality(r) for r in results]
        avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 0
        
        # If quality is sufficient, return
        if avg_quality >= 0.85:
            logger.info("enhancement_converged", quality=avg_quality)
            return results
        
        # Otherwise, attempt refinement
        logger.info(
            "enhancing_results",
            cycle=self.enhancement_cycles,
            quality=avg_quality
        )
        
        # Apply enhancement (placeholder - real implementation would refine)
        enhanced = []
        for result in results:
            enhanced_result = result
            enhanced_result.confidence = min(result.confidence * 1.1, 1.0)
            enhanced.append(enhanced_result)
        
        return enhanced
    
    def _assess_quality(self, result: AgentResult) -> float:
        """Assess quality of agent result."""
        score = 0.0
        
        # Success contributes 50%
        if result.success:
            score += 0.5
        
        # Confidence contributes 30%
        score += result.confidence * 0.3
        
        # Execution time contributes 20% (faster is better)
        if result.execution_time < 1.0:
            score += 0.2
        elif result.execution_time < 5.0:
            score += 0.1
        
        return min(score, 1.0)
    
    async def get_status(self) -> Dict[str, Any]:
        """Get IRIS status."""
        return {
            "active": self.active,
            "enhancement_cycles": self.enhancement_cycles,
            "max_cycles": self.max_cycles,
            "agents_managed": len(self.agents)
        }
