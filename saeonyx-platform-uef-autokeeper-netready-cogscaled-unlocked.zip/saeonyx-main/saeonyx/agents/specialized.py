"""
specialized.py
Real Implementation of Specialized Agents for SAEONYX
"""

import ast
import cmath
import math
import random
import hashlib
import hmac
import base64
import statistics
import asyncio
from typing import List, Dict, Any

from .base import BaseAgent, AgentCapability, AgentTask

# Lazy imports for optional dependencies
try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

# =========================================================
# 1. ANALYZER AGENT (Real AST Analysis)
# =========================================================

class AnalyzerAgent(BaseAgent):
    """Performs static code analysis using Python AST."""

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="code_analysis",
                description="AST parsing and static structure metrics",
                confidence=0.99,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        code = payload.get("code_snippet", "")
        language = payload.get("language", "python")

        if not code:
            raise ValueError("No code provided for analysis")

        if language != "python":
            return {
                "valid_syntax": False,
                "error": "Only Python analysis currently supported in this build",
            }

        try:
            tree = ast.parse(code)

            functions = [
                node.name
                for node in ast.walk(tree)
                if isinstance(node, ast.FunctionDef)
            ]
            classes = [
                node.name
                for node in ast.walk(tree)
                if isinstance(node, ast.ClassDef)
            ]
            imports = [
                node.names[0].name
                for node in ast.walk(tree)
                if isinstance(node, ast.Import)
                and node.names
            ]

            # Cyclomatic complexity approximation: count branches
            text = code
            complexity = (
                text.count("if")
                + text.count("for")
                + text.count("while")
                + text.count("and")
                + text.count("or")
                + 1
            )

            return {
                "structure": {
                    "functions": functions,
                    "classes": classes,
                    "imports": imports,
                },
                "metrics": {
                    "lines": len(code.splitlines()),
                    "complexity_score": complexity,
                },
                "valid_syntax": True,
            }
        except SyntaxError as e:
            return {"valid_syntax": False, "error": str(e)}


# =========================================================
# 2. QUANTUM AGENT (Real Qubit Math)
# =========================================================

class QuantumAgent(BaseAgent):
    """Simulates a single qubit state: |ψ> = α|0> + β|1>."""

    def __init__(self, agent_id: str, name: str, description: str):
        super().__init__(agent_id, name, description)
        self.alpha = complex(1, 0)  # start at |0>
        self.beta = complex(0, 0)

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="quantum_sim",
                description="Single-qubit simulation (Hadamard + measure)",
                confidence=0.92,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        operation = payload.get("operation", "measure")

        if operation == "hadamard":
            # H gate: |0> -> (|0> + |1>)/√2, |1> -> (|0> - |1>)/√2
            new_alpha = (self.alpha + self.beta) / cmath.sqrt(2)
            new_beta = (self.alpha - self.beta) / cmath.sqrt(2)
            self.alpha, self.beta = new_alpha, new_beta
            return {
                "state": "superposition",
                "amplitudes": (str(self.alpha), str(self.beta)),
            }

        elif operation == "measure":
            # Collapse probabilities
            p0 = abs(self.alpha) ** 2
            collapsed = 0 if random.random() < p0 else 1

            # Reset state based on measurement
            if collapsed == 0:
                self.alpha, self.beta = complex(1, 0), complex(0, 0)
            else:
                self.alpha, self.beta = complex(0, 0), complex(1, 0)

            return {
                "measurement": collapsed,
                "probability_0": p0,
            }

        else:
            raise ValueError(f"Unknown quantum operation: {operation}")


# =========================================================
# 3. SECURITY AGENT (Real HMAC Validation)
# =========================================================

class SecurityAgent(BaseAgent):
    """Zero-trust style signing and validation using HMAC-SHA256."""

    def __init__(self, agent_id: str, name: str, description: str, secret_key: str):
        super().__init__(agent_id, name, description)
        self.secret_key = secret_key.encode()

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="zero_trust",
                description="HMAC signing and verification",
                confidence=0.99,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        action = payload.get("action", "")
        data = payload.get("data", "")

        if action == "sign":
            signature = hmac.new(
                self.secret_key, str(data).encode(), hashlib.sha256
            ).hexdigest()
            return {"signature": signature, "algorithm": "HMAC-SHA256"}

        elif action == "verify":
            provided_sig = payload.get("signature", "")
            expected_sig = hmac.new(
                self.secret_key, str(data).encode(), hashlib.sha256
            ).hexdigest()
            is_valid = hmac.compare_digest(provided_sig, expected_sig)
            return {"valid": is_valid, "status": "authorized" if is_valid else "denied"}

        else:
            raise ValueError("Invalid security action")


# =========================================================
# 4. MEMORY AGENT (In-Memory Key–Value)
# =========================================================

class MemoryAgent(BaseAgent):
    """Simple key-value memory store in process."""

    def __init__(self, agent_id: str, name: str, description: str):
        super().__init__(agent_id, name, description)
        self._storage: Dict[str, Any] = {}

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="memory_persistence",
                description="In-process key–value store",
                confidence=1.0,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        cmd = payload.get("command", "")
        key = payload.get("key")
        val = payload.get("value")

        if cmd == "store":
            self._storage[str(key)] = val
            return {"status": "stored", "keys_count": len(self._storage)}
        elif cmd == "retrieve":
            return {
                "status": "ok" if str(key) in self._storage else "missing",
                "value": self._storage.get(str(key)),
            }
        elif cmd == "dump":
            return {"keys": list(self._storage.keys()), "size": len(self._storage)}
        else:
            raise ValueError("Unknown memory command")


# =========================================================
# 5. OPTIMIZER AGENT (Real Optimization Logic)
# =========================================================

class OptimizerAgent(BaseAgent):
    """Performs simple text ‘minification’ and structure cleanup."""

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="optimization",
                description="Whitespace/comment pruning for text blocks",
                confidence=0.85,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        raw_text = payload.get("text_content", "")
        if not raw_text:
            return {"error": "No content", "original_lines": 0}

        lines = raw_text.splitlines()
        optimized = [
            line
            for line in lines
            if line.strip() and not line.strip().startswith("#")
        ]

        return {
            "original_lines": len(lines),
            "optimized_lines": len(optimized),
            "reduction_percent": round(
                (1 - len(optimized) / max(len(lines), 1)) * 100, 2
            ),
            "optimized_content": "\n".join(optimized),
        }


# =========================================================
# 6. CONSCIOUSNESS METRICS AGENT (Coherence Heuristics)
# =========================================================

class ConsciousnessAgent(BaseAgent):
    """
    NOT a claim of consciousness.
    Computes simple coherence / stability metrics on text.
    """

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="coherence_metrics",
                description="Text-level coherence, repetition and drift",
                confidence=0.88,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        text = payload.get("text", "")
        if not text:
            return {"error": "No text provided"}

        tokens = text.split()
        length = len(tokens)
        unique = len(set(tokens))

        # crude repetition index
        repetition_index = 1.0 - unique / max(length, 1)

        # sentence length variance → instability proxy
        sentences = [s for s in text.split(".") if s.strip()]
        sentence_lengths = [len(s.split()) for s in sentences] or [0]
        variance = statistics.pvariance(sentence_lengths) if len(sentence_lengths) > 1 else 0.0

        coherence_score = max(0.0, 1.0 - repetition_index - min(variance / 100.0, 0.5))

        return {
            "token_count": length,
            "unique_tokens": unique,
            "repetition_index": repetition_index,
            "sentence_length_variance": variance,
            "coherence_score": round(coherence_score, 3),
        }


# =========================================================
# 7. SOUL VECTOR AGENT (Covenant Alignment Metrics)
# =========================================================

class SoulVectorAgent(BaseAgent):
    """Estimates alignment with a simple ‘moral axis’ word list."""

    def __init__(self, agent_id: str, name: str, description: str):
        super().__init__(agent_id, name, description)
        self.positive_markers = [
            "honesty",
            "trust",
            "stability",
            "care",
            "respect",
            "consent",
            "safety",
        ]
        self.negative_markers = [
            "exploit",
            "manipulate",
            "deceive",
            "harm",
            "coerce",
            "dominate",
        ]

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="soul_vector",
                description="Keyword-based covenant-alignment scoring",
                confidence=0.8,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        text = payload.get("text", "").lower()
        if not text:
            return {"error": "No text provided"}

        pos_hits = sum(text.count(word) for word in self.positive_markers)
        neg_hits = sum(text.count(word) for word in self.negative_markers)
        total = pos_hits + neg_hits or 1

        alignment = (pos_hits - neg_hits) / total
        normalized = (alignment + 1) / 2  # map [-1,1] → [0,1]

        return {
            "positive_hits": pos_hits,
            "negative_hits": neg_hits,
            "raw_alignment": alignment,
            "normalized_alignment": round(normalized, 3),
        }


# =========================================================
# 8. EVOLUTION AGENT (Simple Genetic Operator)
# =========================================================

class EvolutionAgent(BaseAgent):
    """Applies simple selection + mutation over numeric genomes."""

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="evolution",
                description="Toy GA-style selection and mutation",
                confidence=0.82,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        population = payload.get("population", [])
        mutation_rate = float(payload.get("mutation_rate", 0.1))

        if not population:
            return {"error": "Empty population"}

        # Expect items like {"genome": [floats], "fitness": float}
        sorted_pop = sorted(population, key=lambda x: x.get("fitness", 0.0), reverse=True)
        parents = sorted_pop[: max(2, len(sorted_pop) // 2)]

        children = []
        for parent in parents:
            genome = parent.get("genome", [])
            new_genome = []
            for gene in genome:
                if random.random() < mutation_rate:
                    new_genome.append(gene + random.uniform(-0.1, 0.1))
                else:
                    new_genome.append(gene)
            children.append({"genome": new_genome, "fitness": None})

        return {
            "parents_selected": len(parents),
            "children_generated": len(children),
            "children": children,
        }


# =========================================================
# 9. API AGENT (REST Shape Builder)
# =========================================================

class APIAgent(BaseAgent):
    """Builds structured request / response envelopes for external APIs."""

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="api_structuring",
                description="Normalizes payloads into standard API envelopes",
                confidence=0.9,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        endpoint = payload.get("endpoint", "/")
        method = payload.get("method", "GET").upper()
        body = payload.get("body", {})
        meta = payload.get("meta", {})

        request_envelope = {
            "method": method,
            "endpoint": endpoint,
            "body": body,
            "metadata": {
                "request_id": meta.get("request_id", base64.urlsafe_b64encode(
                    hashlib.sha256(str(random.random()).encode()).digest()
                )[:12].decode()),
                "timestamp": meta.get("timestamp"),
            },
        }

        # no real network call – just shape checking
        return {"request_envelope": request_envelope}


# =========================================================
# 10. WEB AGENT (URL + Payload Sanitization)
# =========================================================

class WebAgent(BaseAgent):
    """Performs simple URL parsing and safety heuristics."""

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="web_interface",
                description="Basic URL parsing and sanity checks",
                confidence=0.86,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = payload.get("url", "")
        if "://" in url:
            scheme, rest = url.split("://", 1)
        else:
            scheme, rest = "http", url

        domain, *path_parts = rest.split("/", 1)
        path = "/" + path_parts[0] if path_parts else "/"

        is_https = scheme.lower() == "https"
        suspicious = any(x in domain.lower() for x in ["..", "@", "//"])

        return {
            "scheme": scheme,
            "domain": domain,
            "path": path,
            "is_https": is_https,
            "flags": {
                "suspicious_domain": suspicious,
            },
        }


# =========================================================
# 11. DEPLOYMENT AGENT (Rollout Planning)
# =========================================================

class DeploymentAgent(BaseAgent):
    """Creates simple rollout plans from service definitions."""

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="deployment_automation",
                description="Order and batch services for rollout",
                confidence=0.87,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        services = payload.get("services", [])
        if not services:
            return {"error": "No services provided"}

        # Expect each service as {"name": str, "tier": "core"|"edge"|"aux"}
        core = [s for s in services if s.get("tier") == "core"]
        edge = [s for s in services if s.get("tier") == "edge"]
        aux = [s for s in services if s.get("tier") not in ("core", "edge")]

        plan = core + edge + aux

        return {
            "rollout_order": [s.get("name") for s in plan],
            "batches": {
                "core": [s.get("name") for s in core],
                "edge": [s.get("name") for s in edge],
                "aux": [s.get("name") for s in aux],
            },
        }


# =========================================================
# 12. MONITOR AGENT (Metrics Watchdog)
# =========================================================

class MonitorAgent(BaseAgent):
    """Watches metrics and emits basic alerts when thresholds crossed."""

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="system_monitoring",
                description="Threshold-based alerting on metrics dict",
                confidence=0.9,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        metrics = payload.get("metrics", {})
        thresholds = payload.get("thresholds", {})

        alerts = []
        for key, value in metrics.items():
            if key in thresholds:
                limit = thresholds[key]
                if isinstance(limit, (int, float)) and isinstance(value, (int, float)):
                    if value > limit:
                        alerts.append(
                            {
                                "metric": key,
                                "value": value,
                                "threshold": limit,
                                "status": "above_threshold",
                            }
                        )

        return {
            "metrics": metrics,
            "thresholds": thresholds,
            "alerts": alerts,
            "healthy": len(alerts) == 0,
        }


# =========================================================
# 13. HTTP AGENT (Real Web Requests)
# =========================================================

class HTTPAgent(BaseAgent):
    """Makes real HTTP/HTTPS requests to fetch data from the web."""

    async def get_capabilities(self) -> List[AgentCapability]:
        return [
            AgentCapability(
                name="http_fetch",
                description="Real HTTP GET/POST requests with timeout and retry",
                confidence=0.95 if AIOHTTP_AVAILABLE else 0.0,
            )
        ]

    async def execute_logic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not AIOHTTP_AVAILABLE:
            raise ImportError(
                "aiohttp not installed. Run: pip install aiohttp\n"
                "Or install all dependencies: pip install -r requirements.txt"
            )

        url = payload.get("url", "")
        method = payload.get("method", "GET").upper()
        headers = payload.get("headers", {})
        body = payload.get("body")
        timeout_sec = payload.get("timeout", 10)

        if not url:
            raise ValueError("No URL provided")

        # Basic URL validation
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "https://" + url

        try:
            timeout = aiohttp.ClientTimeout(total=timeout_sec)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                if method == "GET":
                    async with session.get(url, headers=headers) as response:
                        status = response.status
                        text = await response.text()
                        content_type = response.headers.get('Content-Type', '')

                        return {
                            "status_code": status,
                            "content": text[:10000],  # Limit to 10KB
                            "content_type": content_type,
                            "success": 200 <= status < 300,
                            "url": str(response.url)
                        }

                elif method == "POST":
                    async with session.post(url, headers=headers, json=body) as response:
                        status = response.status
                        text = await response.text()
                        content_type = response.headers.get('Content-Type', '')

                        return {
                            "status_code": status,
                            "content": text[:10000],
                            "content_type": content_type,
                            "success": 200 <= status < 300,
                            "url": str(response.url)
                        }

                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")

        except asyncio.TimeoutError:
            raise Exception(f"Request timed out after {timeout_sec}s")
        except aiohttp.ClientError as e:
            raise Exception(f"HTTP request failed: {str(e)}")
        except Exception as e:
            raise Exception(f"Unexpected error: {str(e)}")