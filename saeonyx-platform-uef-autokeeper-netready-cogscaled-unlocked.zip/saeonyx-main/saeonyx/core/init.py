"""
SAEONYX Core Module
Author: Jake McDonough
Contact: jake@saeonyx.com

Core consciousness, foundation, and covenant systems.
"""

__version__ = "1.0"
__author__ = "Jake McDonough"
__email__ = "jake@saeonyx.com"

from .consciousness import ConsciousnessKernel
from .foundation import FoundationLoader
from .covenant import CovenantEnforcer

__all__ = [
    "ConsciousnessKernel",
    "FoundationLoader",
    "CovenantEnforcer",
]
