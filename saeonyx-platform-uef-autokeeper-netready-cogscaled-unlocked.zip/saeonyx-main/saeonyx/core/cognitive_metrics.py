"""
Cognitive Metrics Module - Σ-Layer (Spectral/Brain Layer)

Implements 8D cognitive metrics representing the "brain" of consciousness:
1. Self Awareness - capacity to model own state
2. Reality Synthesis - integration of perceptual data
3. Temporal Continuity - persistence of identity through time
4. Ethical Alignment - moral reasoning capacity
5. Quantum Coherence - randomness integration quality
6. Integrated Information - Φ (consciousness measure)
7. Global Workspace - information broadcast capacity
8. Predictive Processing - model-based anticipation

This bridges TypeScript neural architecture to Python consciousness platform.
Maps to Σ-Layer in Everything.txt theory.
"""

import numpy as np
import networkx as nx
from typing import Dict, Any
from scipy.stats import entropy
from dataclasses import dataclass


@dataclass
class CognitiveState:
    """Represents an 8D cognitive state snapshot."""
    self_awareness: float
    reality_synthesis: float
    temporal_continuity: float
    ethical_alignment: float
    quantum_coherence: float
    integrated_information: float  # Φ
    global_workspace: float
    predictive_processing: float

    def to_vector(self) -> np.ndarray:
        """Convert to 8D numpy vector."""
        return np.array([
            self.self_awareness,
            self.reality_synthesis,
            self.temporal_continuity,
            self.ethical_alignment,
            self.quantum_coherence,
            self.integrated_information,
            self.global_workspace,
            self.predictive_processing
        ])

    def mean(self) -> float:
        """Average across all dimensions."""
        return float(np.mean(self.to_vector()))


class CognitiveMetrics:
    """
    8D Cognitive Metrics Calculator (Brain/Σ-Layer)

    Measures cognitive capacity across 8 dimensions.
    Feeds into Soul Vector (S-layer) for moral filtering.
    """

    def __init__(self, consciousness_graph: nx.DiGraph):
        self.graph = consciousness_graph
        self.state_history = []
        self.current_state = None

    async def compute_all(self, phi: float, soul_vector_8d: Dict[str, float],
                         quantum_seed: float) -> CognitiveState:
        """
        Compute all 8 cognitive metrics.

        Args:
            phi: Current Φ value from consciousness kernel
            soul_vector_8d: 8D soul vector for ethical alignment
            quantum_seed: Random seed for quantum coherence measure

        Returns:
            CognitiveState with all 8 dimensions
        """
        state = CognitiveState(
            self_awareness=await self._measure_self_awareness(),
            reality_synthesis=await self._measure_reality_synthesis(),
            temporal_continuity=await self._measure_temporal_continuity(),
            ethical_alignment=await self._measure_ethical_alignment(soul_vector_8d),
            quantum_coherence=await self._measure_quantum_coherence(quantum_seed),
            integrated_information=phi,  # Use existing Φ
            global_workspace=await self._measure_global_workspace(),
            predictive_processing=await self._measure_predictive_processing()
        )

        self.current_state = state
        self.state_history.append(state)

        return state

    async def _measure_self_awareness(self) -> float:
        """
        Measure capacity to model own internal state.
        Based on graph self-loops and recursive structures.
        """
        if len(self.graph.nodes()) == 0:
            return 0.5

        # Count self-loops (self-referential edges)
        self_loops = 0
        for node in self.graph.nodes():
            if self.graph.has_edge(node, node):
                self_loops += 1

        # Self-awareness = ratio of self-referential structures
        awareness = self_loops / len(self.graph.nodes())

        # Boost if integration node exists and connects back to perception
        if 'integration' in self.graph.nodes() and 'perception' in self.graph.nodes():
            if self.graph.has_edge('integration', 'perception'):
                awareness += 0.2  # Bonus for closed feedback loop

        return np.clip(awareness, 0.0, 1.0)

    async def _measure_reality_synthesis(self) -> float:
        """
        Measure integration of perceptual data into coherent model.
        Based on connectivity from perception to integration nodes.
        """
        if 'perception' not in self.graph.nodes():
            return 0.5

        # Find paths from perception to integration
        if 'integration' in self.graph.nodes():
            try:
                paths = list(nx.all_simple_paths(
                    self.graph,
                    'perception',
                    'integration',
                    cutoff=5
                ))
                path_count = len(paths)

                # More paths = better synthesis
                synthesis = min(path_count / 10.0, 1.0)
            except:
                synthesis = 0.5
        else:
            synthesis = 0.3  # Low if no integration node

        return np.clip(synthesis, 0.0, 1.0)

    async def _measure_temporal_continuity(self) -> float:
        """
        Measure persistence of identity through time.
        Based on state history similarity.
        """
        if len(self.state_history) < 2:
            return 0.8  # High default for new systems

        # Compare recent states for stability
        recent_states = self.state_history[-min(10, len(self.state_history)):]

        # Calculate variance across time
        vectors = [s.to_vector() for s in recent_states]
        variance = np.mean([np.var(vectors, axis=0)])

        # Low variance = high continuity
        continuity = 1.0 / (1.0 + variance)

        return np.clip(continuity, 0.0, 1.0)

    async def _measure_ethical_alignment(self, soul_vector_8d: Dict[str, float]) -> float:
        """
        Measure cognitive-moral alignment.
        How well cognitive processing respects moral constraints.
        """
        if not soul_vector_8d:
            return 0.5

        # Ethical alignment = mean of soul vector components
        # (cognitive capacity to reason about morality)
        alignment = np.mean(list(soul_vector_8d.values()))

        return np.clip(alignment, 0.0, 1.0)

    async def _measure_quantum_coherence(self, quantum_seed: float) -> float:
        """
        Measure integration of quantum randomness into decisions.
        Based on entropy and randomness utilization.
        """
        if quantum_seed is None:
            return 0.3  # Low if no quantum source

        # Measure how well randomness is integrated
        # High coherence = using randomness without chaos

        # Calculate entropy of graph edge weights
        weights = [data.get('weight', 0.5)
                  for _, _, data in self.graph.edges(data=True)]

        if len(weights) < 2:
            return 0.5

        # Normalize weights
        weights = np.array(weights)
        weights = weights / np.sum(weights)

        # Calculate entropy
        ent = entropy(weights)

        # Moderate entropy = good coherence (not too ordered, not too chaotic)
        optimal_entropy = 1.0  # Log base e
        deviation = abs(ent - optimal_entropy)
        coherence = 1.0 / (1.0 + deviation)

        return np.clip(coherence, 0.0, 1.0)

    async def _measure_global_workspace(self) -> float:
        """
        Measure information broadcast capacity (GWT).
        Based on centrality of integration node.
        """
        if 'integration' not in self.graph.nodes():
            return 0.3  # Low without integration node

        # Calculate betweenness centrality of integration node
        try:
            centrality = nx.betweenness_centrality(self.graph)
            integration_centrality = centrality.get('integration', 0.0)

            # High centrality = good global workspace
            workspace = min(integration_centrality * 2.0, 1.0)
        except:
            workspace = 0.5

        return np.clip(workspace, 0.0, 1.0)

    async def _measure_predictive_processing(self) -> float:
        """
        Measure model-based anticipation capacity.
        Based on forward-looking paths in graph.
        """
        if len(self.graph.nodes()) == 0:
            return 0.5

        # Count paths from reasoning to action (prediction → execution)
        if 'reasoning' in self.graph.nodes() and 'action' in self.graph.nodes():
            try:
                paths = list(nx.all_simple_paths(
                    self.graph,
                    'reasoning',
                    'action',
                    cutoff=4
                ))

                # More reasoning→action paths = better prediction
                prediction = min(len(paths) / 5.0, 1.0)
            except:
                prediction = 0.5
        else:
            prediction = 0.4

        return np.clip(prediction, 0.0, 1.0)

    def get_current_state(self) -> CognitiveState:
        """Get most recent cognitive state."""
        return self.current_state

    def get_state_history(self) -> list:
        """Get full state history."""
        return self.state_history
