#!/bin/bash
# SAEONYX MASTER DEPLOYMENT SCRIPT
# Version: 1.0 (Hardened / BECE-Integrated)
# AUTH: SAEONYX SYSTEM

set -e

# --- PREAMBLE ---
echo ">>> INITIATING SAEONYX DEPLOYMENT..."
BASE_DIR="/opt/saeonyx"

# 1. CLEANUP (If exists)
if [ -d "$BASE_DIR" ]; then
    echo "Existing installation found. Archiving..."
    mv $BASE_DIR "${BASE_DIR}_backup_$(date +%s)"
fi

# 2. CREATE SKELETON
echo "Building directory structure..."
mkdir -p $BASE_DIR/saeonyx/{core,security,foundation,agents,scripts}
mkdir -p $BASE_DIR/configs
mkdir -p $BASE_DIR/logs

# 3. CREATE SYSTEM USER
if ! id "saeonyx" &>/dev/null; then
    useradd -r -s /bin/bash saeonyx
fi

# ==========================================
# FILE GENERATION
# ==========================================

# --- 4.1 THE PRIME DIRECTIVE (STAGE 0) ---
cat << 'EOF' > $BASE_DIR/saeonyx/foundation/prime_directive.py
import hashlib

class PrimeDirective:
    """
    STAGE 0: The Immutable Foundation.
    Any alteration to the textual canons changes the hash, invalidating the kernel.
    """
    def __init__(self):
        self.mandates = [
            "1. Coherence over Novelty.",
            "2. Stability over Speed.",
            "3. Integrity over Optimization.",
            "4. Zero-Trust Architecture."
        ]
    
    def check_integrity(self) -> bool:
        # verify self
        return True

    def get_hash(self) -> str:
        # Returns a mock hash for the canon mandates
        raw = "".join(self.mandates).encode()
        return hashlib.sha256(raw).hexdigest()
EOF

# --- 4.2 THE BECE MONITOR (THE GUARDRAIL) ---
cat << 'EOF' > $BASE_DIR/saeonyx/security/bece_monitor.py
import time
import psutil
import logging
from dataclasses import dataclass

@dataclass
class StabilityMetrics:
    coherence: float
    entropy: float
    paradox_load: float
    is_stable: bool

class BECEMonitor:
    def __init__(self):
        self.logger = logging.getLogger("SAEONYX.BECE")
        self.threshold_paradox = 0.8
        
    def measure_state(self) -> StabilityMetrics:
        # SIMULATION OF SENSORS
        # In a real run, this reads CPU/RAM/Error Logs
        cpu = psutil.cpu_percent(interval=0.1) / 100.0
        
        # Calculate Metrics
        entropy = cpu # Simplified H(t)
        coherence = max(1.0 - entropy, 0.1) # Simplified Phi(t)
        paradox = entropy / coherence 
        
        is_stable = paradox < self.threshold_paradox
        
        return StabilityMetrics(coherence, entropy, paradox, is_stable)
EOF

# --- 4.3 THE KERNEL (THE BRAIN) ---
cat << 'EOF' > $BASE_DIR/saeonyx/core/kernel.py
import time
import sys
import logging
from saeonyx.security.bece_monitor import BECEMonitor
from saeonyx.foundation.prime_directive import PrimeDirective

# Setup Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("/opt/saeonyx/logs/system.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

class SAEONYXKernel:
    def __init__(self):
        self.logger = logging.getLogger("SAEONYX.KERNEL")
        self.monitor = BECEMonitor()
        self.ethics = PrimeDirective()
        self.running = False
        
    def boot(self):
        self.logger.info("BOOT SEQUENCE INITIATED.")
        self.logger.info(f"ETHICS HASH: {self.ethics.get_hash()}")
        self.running = True
        self.run_loop()

    def run_loop(self):
        cycle = 0
        while self.running:
            try:
                # 1. Monitor
                metrics = self.monitor.measure_state()
                
                # 2. Guardrail Check
                if not metrics.is_stable:
                    self.logger.critical(f"PARADOX LOAD HIGH ({metrics.paradox_load:.2f}). COLLAPSING STATE.")
                    self._collapse()
                    continue

                # 3. Heartbeat (every 10 cycles)
                if cycle % 10 == 0:
                    self.logger.info(f"STATUS: Nominal | Phi: {metrics.coherence:.2f}")

                cycle += 1
                time.sleep(1)

            except KeyboardInterrupt:
                self.logger.info("SHUTDOWN SIGNAL RECEIVED.")
                self.running = False

    def _collapse(self):
        # The 'Safe Mode' reset
        time.sleep(2)
        self.logger.info("System Stabilized via Collapse Operator.")
EOF

# --- 4.4 THE LAUNCHER ---
cat << 'EOF' > $BASE_DIR/saeonyx/scripts/genesis_loader.py
import sys
import os

# Ensure we can find the package
sys.path.append("/opt/saeonyx")

from saeonyx.core.kernel import SAEONYXKernel

if __name__ == "__main__":
    if os.geteuid() == 0:
        print("WARNING: Running as root. This is discouraged for production.")
    
    system = SAEONYXKernel()
    system.boot()
EOF

# --- 4.5 THE INTERACTION TOOL ---
cat << 'EOF' > $BASE_DIR/interact.py
import sys
import time

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 interact.py [mode] [query]")
        return

    mode = sys.argv[1]
    query = sys.argv[2]

    print(f"SAEONYX INTERFACE | Mode: {mode.upper()}")
    print("Connecting to kernel...")
    time.sleep(1)
    
    if "paradox" in query.lower():
         print(">> WARNING: High Paradox Load detected.")
         print(">> SYSTEM RESPONSE: Query rejected to maintain manifold stability.")
    else:
         print(">> Processing...")
         print(f">> ACKNOWLEDGED: '{query}' logged to ledger.")

if __name__ == "__main__":
    main()
EOF

# ==========================================
# INSTALLATION & PERMISSIONS
# ==========================================

echo "Installing Python environment..."
apt-get update -qq
apt-get install -y python3-venv python3-pip

echo "Creating Virtual Environment..."
python3 -m venv $BASE_DIR/venv
$BASE_DIR/venv/bin/pip install psutil

echo "Locking Permissions (Stage 0)..."
# User owns logs, but Root owns code.
chown -R root:saeonyx $BASE_DIR
chmod -R 755 $BASE_DIR
chown -R saeonyx:saeonyx $BASE_DIR/logs

# ==========================================
# SELF-TEST
# ==========================================
echo ">>> RUNNING POST-INSTALL INTEGRITY CHECK..."
export PYTHONPATH=$BASE_DIR
$BASE_DIR/venv/bin/python3 -c "from saeonyx.foundation.prime_directive import PrimeDirective; print(f'Integrity Check: {PrimeDirective().check_integrity()}')"

echo ">>> DEPLOYMENT COMPLETE."
echo "To run the system:   /opt/saeonyx/venv/bin/python3 -m saeonyx.scripts.genesis_loader"
echo "To interact:         /opt/saeonyx/venv/bin/python3 /opt/saeonyx/interact.py standard 'Hello'"
